#include "AvatarRenderer.h"
#include <cmath>

#pragma comment(lib, "gdiplus.lib")

AvatarRenderer::AvatarRenderer() : m_pBackHair(nullptr), m_pBodyTorso(nullptr), m_pHead(nullptr), m_pBangs(nullptr),
                                   m_pEyesOpen(nullptr), m_pEyesClosed(nullptr), m_pEyesThinking(nullptr),
                                   m_pMouthClosed(nullptr), m_pMouthOpen(nullptr), m_pMouthHalf(nullptr) {
}

AvatarRenderer::~AvatarRenderer() {
    if (m_pBackHair) delete m_pBackHair;
    if (m_pBodyTorso) delete m_pBodyTorso;
    if (m_pHead) delete m_pHead;
    if (m_pBangs) delete m_pBangs;
    if (m_pEyesOpen) delete m_pEyesOpen;
    if (m_pEyesClosed) delete m_pEyesClosed;
    if (m_pEyesThinking) delete m_pEyesThinking;
    if (m_pMouthClosed) delete m_pMouthClosed;
    if (m_pMouthOpen) delete m_pMouthOpen;
    if (m_pMouthHalf) delete m_pMouthHalf;
}

void AvatarRenderer::initialize() {
    loadPartAssets();
    buildProceduralParts();
}

void AvatarRenderer::loadPartAssets() {
    m_pBackHair = Gdiplus::Bitmap::FromFile(L"assets/avatar/back_hair.png");
    if (m_pBackHair && m_pBackHair->GetLastStatus() != Gdiplus::Ok) { delete m_pBackHair; m_pBackHair = nullptr; }

    m_pBodyTorso = Gdiplus::Bitmap::FromFile(L"assets/avatar/body_torso.png");
    if (m_pBodyTorso && m_pBodyTorso->GetLastStatus() != Gdiplus::Ok) { delete m_pBodyTorso; m_pBodyTorso = nullptr; }

    m_pHead = Gdiplus::Bitmap::FromFile(L"assets/avatar/head.png");
    if (m_pHead && m_pHead->GetLastStatus() != Gdiplus::Ok) { delete m_pHead; m_pHead = nullptr; }

    m_pBangs = Gdiplus::Bitmap::FromFile(L"assets/avatar/bangs.png");
    if (m_pBangs && m_pBangs->GetLastStatus() != Gdiplus::Ok) { delete m_pBangs; m_pBangs = nullptr; }

    m_pEyesOpen = Gdiplus::Bitmap::FromFile(L"assets/avatar/eyes_open.png");
    if (m_pEyesOpen && m_pEyesOpen->GetLastStatus() != Gdiplus::Ok) { delete m_pEyesOpen; m_pEyesOpen = nullptr; }

    m_pEyesClosed = Gdiplus::Bitmap::FromFile(L"assets/avatar/eyes_closed.png");
    if (m_pEyesClosed && m_pEyesClosed->GetLastStatus() != Gdiplus::Ok) { delete m_pEyesClosed; m_pEyesClosed = nullptr; }

    m_pEyesThinking = Gdiplus::Bitmap::FromFile(L"assets/avatar/eyes_thinking.png");
    if (m_pEyesThinking && m_pEyesThinking->GetLastStatus() != Gdiplus::Ok) { delete m_pEyesThinking; m_pEyesThinking = nullptr; }

    m_pMouthClosed = Gdiplus::Bitmap::FromFile(L"assets/avatar/mouth_closed.png");
    if (m_pMouthClosed && m_pMouthClosed->GetLastStatus() != Gdiplus::Ok) { delete m_pMouthClosed; m_pMouthClosed = nullptr; }

    m_pMouthOpen = Gdiplus::Bitmap::FromFile(L"assets/avatar/mouth_open.png");
    if (m_pMouthOpen && m_pMouthOpen->GetLastStatus() != Gdiplus::Ok) { delete m_pMouthOpen; m_pMouthOpen = nullptr; }

    m_pMouthHalf = Gdiplus::Bitmap::FromFile(L"assets/avatar/mouth_half.png");
    if (m_pMouthHalf && m_pMouthHalf->GetLastStatus() != Gdiplus::Ok) { delete m_pMouthHalf; m_pMouthHalf = nullptr; }
}

void AvatarRenderer::buildProceduralParts() {
    int size = 200;
    
    Gdiplus::Color colorHair(255, 68, 48, 84);            
    Gdiplus::Color colorHairLight(255, 120, 90, 140);     
    Gdiplus::Color colorSkin(255, 255, 240, 233);         
    Gdiplus::Color colorBlush(120, 255, 130, 140);        
    
    Gdiplus::SolidBrush hairBrush(colorHair);
    Gdiplus::SolidBrush skinBrush(colorSkin);
    Gdiplus::SolidBrush blushBrush(colorBlush);
    
    Gdiplus::SolidBrush eyeWhite(Gdiplus::Color(255, 255, 255, 255));
    Gdiplus::SolidBrush eyeIris(Gdiplus::Color(255, 110, 70, 150));        
    Gdiplus::SolidBrush eyeIrisLight(Gdiplus::Color(255, 175, 130, 220));   
    
    Gdiplus::SolidBrush shirtWhite(Gdiplus::Color(255, 250, 250, 252));     
    Gdiplus::SolidBrush vestGreen(Gdiplus::Color(255, 170, 225, 185));      
    Gdiplus::SolidBrush ribbonRed(Gdiplus::Color(255, 205, 50, 75));        
    Gdiplus::SolidBrush skirtDark(Gdiplus::Color(255, 45, 45, 55));         

    // 1. Back Hair Layer
    if (!m_pBackHair) {
        m_pBackHair = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pBackHair);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
        
        g.FillEllipse(&hairBrush, 45.0f, 55.0f, 95.0f, 95.0f);
        g.FillEllipse(&hairBrush, 44.0f, 100.0f, 32.0f, 85.0f);
        
        g.FillEllipse(&hairBrush, 125.0f, 75.0f, 40.0f, 60.0f);
        Gdiplus::SolidBrush tieBand(Gdiplus::Color(255, 80, 80, 90));
        g.FillEllipse(&tieBand, 125.0f, 80.0f, 8.0f, 6.0f);
    }

    // 2. Body / Torso Layer
    if (!m_pBodyTorso) {
        m_pBodyTorso = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pBodyTorso);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        g.FillRectangle(&skinBrush, 92.0f, 118.0f, 16.0f, 15.0f);

        Gdiplus::GraphicsPath shoulderPath;
        shoulderPath.AddArc(64.0f, 128.0f, 72.0f, 40.0f, 180, 180);
        g.FillPath(&shirtWhite, &shoulderPath);
        g.FillRectangle(&shirtWhite, 64.0f, 148.0f, 72.0f, 30.0f);

        Gdiplus::GraphicsPath greenVestPath;
        greenVestPath.AddArc(72.0f, 138.0f, 56.0f, 35.0f, 0, 180);
        g.FillPath(&vestGreen, &greenVestPath);
        g.FillRectangle(&vestGreen, 72.0f, 155.0f, 56.0f, 23.0f);

        g.FillRectangle(&skirtDark, 62.0f, 170.0f, 76.0f, 12.0f);

        Gdiplus::PointF leftCollar[3] = {
            Gdiplus::PointF(86.0f, 124.0f),
            Gdiplus::PointF(96.0f, 126.0f),
            Gdiplus::PointF(84.0f, 138.0f)
        };
        g.FillPolygon(&shirtWhite, leftCollar, 3);
        
        Gdiplus::PointF rightCollar[3] = {
            Gdiplus::PointF(114.0f, 124.0f),
            Gdiplus::PointF(104.0f, 126.0f),
            Gdiplus::PointF(116.0f, 138.0f)
        };
        g.FillPolygon(&shirtWhite, rightCollar, 3);

        g.FillEllipse(&ribbonRed, 93.0f, 136.0f, 14.0f, 8.0f); 
        Gdiplus::PointF bowLeft[3] = {
            Gdiplus::PointF(95.0f, 140.0f),
            Gdiplus::PointF(82.0f, 148.0f),
            Gdiplus::PointF(88.0f, 136.0f)
        };
        g.FillPolygon(&ribbonRed, bowLeft, 3);
        Gdiplus::PointF bowRight[3] = {
            Gdiplus::PointF(105.0f, 140.0f),
            Gdiplus::PointF(118.0f, 148.0f),
            Gdiplus::PointF(112.0f, 138.0f)
        };
        g.FillPolygon(&ribbonRed, bowRight, 3);
    }

    // 3. Head / Face Base Layer
    if (!m_pHead) {
        m_pHead = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pHead);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        g.FillEllipse(&skinBrush, 62.0f, 65.0f, 76.0f, 60.0f);

        g.FillEllipse(&blushBrush, 72.0f, 108.0f, 14.0f, 7.0f);
        g.FillEllipse(&blushBrush, 114.0f, 108.0f, 14.0f, 7.0f);
    }

    // 4. Hair Bangs Layer
    if (!m_pBangs) {
        m_pBangs = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pBangs);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        g.FillEllipse(&hairBrush, 60.0f, 56.0f, 80.0f, 32.0f); 
        g.FillEllipse(&hairBrush, 58.0f, 80.0f, 11.0f, 45.0f);
        g.FillEllipse(&hairBrush, 131.0f, 80.0f, 11.0f, 45.0f);

        Gdiplus::PointF bang1[3] = {
            Gdiplus::PointF(76.0f, 68.0f),
            Gdiplus::PointF(86.0f, 90.0f),
            Gdiplus::PointF(92.0f, 68.0f)
        };
        g.FillPolygon(&hairBrush, bang1, 3);

        Gdiplus::PointF bang2[3] = {
            Gdiplus::PointF(94.0f, 68.0f),
            Gdiplus::PointF(100.0f, 92.0f),
            Gdiplus::PointF(108.0f, 68.0f)
        };
        g.FillPolygon(&hairBrush, bang2, 3);

        Gdiplus::PointF bang3[3] = {
            Gdiplus::PointF(106.0f, 68.0f),
            Gdiplus::PointF(116.0f, 90.0f),
            Gdiplus::PointF(122.0f, 68.0f)
        };
        g.FillPolygon(&hairBrush, bang3, 3);

        Gdiplus::Pen highlightPen(colorHairLight, 2.0f);
        g.DrawArc(&highlightPen, 70.0f, 60.0f, 60.0f, 20.0f, 200, 140);
    }

    // 5. Open Eyes Layer
    if (!m_pEyesOpen) {
        m_pEyesOpen = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pEyesOpen);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        float eyeW = 16.0f;
        float eyeH = 22.0f;
        float eyeY = 93.0f;

        g.FillEllipse(&eyeWhite, 83.0f - eyeW, eyeY, eyeW, eyeH);
        g.FillEllipse(&eyeWhite, 117.0f, eyeY, eyeW, eyeH);

        g.FillEllipse(&eyeIris, 83.0f - eyeW + 1.0f, eyeY + 1.0f, eyeW - 2.0f, eyeH - 2.0f);
        g.FillEllipse(&eyeIris, 117.0f + 1.0f, eyeY + 1.0f, eyeW - 2.0f, eyeH - 2.0f);

        g.FillEllipse(&eyeIrisLight, 83.0f - eyeW + 3.0f, eyeY + 8.0f, eyeW - 6.0f, eyeH - 10.0f);
        g.FillEllipse(&eyeIrisLight, 117.0f + 3.0f, eyeY + 8.0f, eyeW - 6.0f, eyeH - 10.0f);

        g.FillEllipse(&eyeWhite, 83.0f - eyeW + 3.5f, eyeY + 3.0f, 4.5f, 6.5f);
        g.FillEllipse(&eyeWhite, 117.0f + 3.5f, eyeY + 3.0f, 4.5f, 6.5f);
        g.FillEllipse(&eyeWhite, 83.0f - eyeW + 9.5f, eyeY + 12.0f, 2.5f, 2.5f);
        g.FillEllipse(&eyeWhite, 117.0f + 9.5f, eyeY + 12.0f, 2.5f, 2.5f);

        Gdiplus::Pen eyelashPen(colorHair, 2.2f);
        g.DrawArc(&eyelashPen, 83.0f - eyeW - 0.5f, eyeY - 0.5f, eyeW + 1.0f, 8.0f, 180, 180);
        g.DrawArc(&eyelashPen, 117.0f - 0.5f, eyeY - 0.5f, eyeW + 1.0f, 8.0f, 180, 180);

        Gdiplus::Pen browPen(colorHair, 1.2f);
        g.DrawArc(&browPen, 83.0f - eyeW - 1.0f, eyeY - 6.0f, eyeW + 2.0f, 6.0f, 190, 160);
        g.DrawArc(&browPen, 117.0f - 1.0f, eyeY - 6.0f, eyeW + 2.0f, 6.0f, 190, 160);
    }

    // 6. Closed / Blinking Eyes Layer
    if (!m_pEyesClosed) {
        m_pEyesClosed = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pEyesClosed);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        float eyeW = 16.0f;
        float eyeY = 93.0f;

        Gdiplus::Pen closedEyePen(colorHair, 2.2f);
        g.DrawArc(&closedEyePen, 83.0f - eyeW, eyeY + 9.0f, eyeW, 6.0f, 180, 180);
        g.DrawArc(&closedEyePen, 117.0f, eyeY + 9.0f, eyeW, 6.0f, 180, 180);
    }

    // 7. Thinking / Shifty Eyes Layer
    if (!m_pEyesThinking) {
        m_pEyesThinking = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pEyesThinking);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        float eyeW = 16.0f;
        float eyeH = 22.0f;
        float eyeY = 93.0f;
        
        float lookX = -2.5f;
        float lookY = -2.5f;

        g.FillEllipse(&eyeWhite, 83.0f - eyeW, eyeY, eyeW, eyeH);
        g.FillEllipse(&eyeWhite, 117.0f, eyeY, eyeW, eyeH);

        g.FillEllipse(&eyeIris, 83.0f - eyeW + 1.0f + lookX, eyeY + 1.0f + lookY, eyeW - 2.0f, eyeH - 2.0f);
        g.FillEllipse(&eyeIris, 117.0f + 1.0f + lookX, eyeY + 1.0f + lookY, eyeW - 2.0f, eyeH - 2.0f);

        g.FillEllipse(&eyeIrisLight, 83.0f - eyeW + 3.0f + lookX, eyeY + 8.0f + lookY, eyeW - 6.0f, eyeH - 10.0f);
        g.FillEllipse(&eyeIrisLight, 117.0f + 3.0f + lookX, eyeY + 8.0f + lookY, eyeW - 6.0f, eyeH - 10.0f);

        g.FillEllipse(&eyeWhite, 83.0f - eyeW + 3.5f + lookX, eyeY + 3.0f + lookY, 4.5f, 6.5f);
        g.FillEllipse(&eyeWhite, 117.0f + 3.5f + lookX, eyeY + 3.0f + lookY, 4.5f, 6.5f);

        Gdiplus::Pen eyelashPen(colorHair, 2.2f);
        g.DrawArc(&eyelashPen, 83.0f - eyeW - 0.5f, eyeY - 0.5f, eyeW + 1.0f, 8.0f, 180, 180);
        g.DrawArc(&eyelashPen, 117.0f - 0.5f, eyeY - 0.5f, eyeW + 1.0f, 8.0f, 180, 180);

        Gdiplus::Pen browPen(colorHair, 1.2f);
        g.DrawArc(&browPen, 83.0f - eyeW - 1.0f, eyeY - 6.0f, eyeW + 2.0f, 6.0f, 190, 160);
        g.DrawArc(&browPen, 117.0f - 1.0f, eyeY - 6.0f, eyeW + 2.0f, 6.0f, 190, 160);
    }

    // 8. Closed Mouth Layer
    if (!m_pMouthClosed) {
        m_pMouthClosed = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pMouthClosed);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        Gdiplus::Pen mouthPen(Gdiplus::Color(255, 170, 95, 95), 1.8f);
        g.DrawArc(&mouthPen, 98.0f, 115.0f, 7.0f, 3.0f, 0, 180);
    }

    // 9. Half Open Mouth Layer
    if (!m_pMouthHalf) {
        m_pMouthHalf = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pMouthHalf);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        Gdiplus::Pen mouthPen(Gdiplus::Color(255, 170, 95, 95), 1.8f);
        Gdiplus::SolidBrush mouthOpenBrush(Gdiplus::Color(255, 230, 95, 105));
        
        g.FillEllipse(&mouthOpenBrush, 97.0f, 114.0f, 8.0f, 4.0f);
        g.DrawEllipse(&mouthPen, 97.0f, 114.0f, 8.0f, 4.0f);
    }

    // 10. Fully Open Mouth Layer
    if (!m_pMouthOpen) {
        m_pMouthOpen = new Gdiplus::Bitmap(size, size, PixelFormat32bppARGB);
        Gdiplus::Graphics g(m_pMouthOpen);
        g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);

        Gdiplus::Pen mouthPen(Gdiplus::Color(255, 170, 95, 95), 1.8f);
        Gdiplus::SolidBrush mouthOpenBrush(Gdiplus::Color(255, 230, 95, 105));
        
        g.FillEllipse(&mouthOpenBrush, 96.0f, 114.0f, 9.0f, 8.0f);
        g.DrawEllipse(&mouthPen, 96.0f, 114.0f, 9.0f, 8.0f);
    }
}

void AvatarRenderer::render(Gdiplus::Graphics& graphics, float cx, float cy, const std::string& state, int tick, float speakingBounce, float breathOffset, const std::string& speechBubble) {
    float size = 200.0f;
    float drawScale = 0.85f;
    
    // Save outer transformation matrix
    Gdiplus::GraphicsState gOuterState = graphics.Save();
    graphics.TranslateTransform(cx, cy + 20.0f);
    graphics.ScaleTransform(drawScale, drawScale);
    graphics.TranslateTransform(-100.0f, -100.0f);

    // ==========================================
    // LAYER 1: BACK HAIR (Dynamic Sway)
    // ==========================================
    Gdiplus::GraphicsState gBackHair = graphics.Save();
    float hairSway = sinf(tick * 0.05f) * 1.6f;
    if (state == "SPEAKING") {
        hairSway = sinf(tick * 0.15f) * 2.5f;
    } else if (state == "THINKING") {
        hairSway = sinf(tick * 0.03f) * 0.8f;
    }
    graphics.TranslateTransform(100.0f, 85.0f);
    graphics.RotateTransform(hairSway);
    graphics.TranslateTransform(-100.0f, -85.0f);
    graphics.DrawImage(m_pBackHair, 0.0f, 0.0f, size, size);
    graphics.Restore(gBackHair);

    // ==========================================
    // LAYER 2: BODY / TORSO (Posture shifts)
    // ==========================================
    Gdiplus::GraphicsState gBody = graphics.Save();
    float bodyScaleY = 1.0f + sinf(tick * 0.08f) * 0.005f;

    if (state == "SPEAKING") {
        bodyScaleY = 1.0f + sinf(tick * 0.15f) * 0.01f;
        graphics.TranslateTransform(0.0f, speakingBounce * 0.6f);
    } else if (state == "LISTENING") {
        bodyScaleY = 1.01f + sinf(tick * 0.04f) * 0.002f;
    }

    graphics.TranslateTransform(100.0f, 160.0f);
    graphics.ScaleTransform(1.0f, bodyScaleY);
    graphics.TranslateTransform(-100.0f, -160.0f);
    graphics.DrawImage(m_pBodyTorso, 0.0f, 0.0f, size, size);
    graphics.Restore(gBody);

    // ==========================================
    // LAYER 3: HEAD / FACE BASE (State tilt)
    // ==========================================
    Gdiplus::GraphicsState gHead = graphics.Save();

    float headTilt   = 0.0f;
    float headOffsetY = breathOffset * 0.6f;

    if (state == "THINKING") {
        headTilt = -6.2f + sinf(tick * 0.08f) * 1.2f;
    } else if (state == "SPEAKING") {
        headTilt = sinf(tick * 0.22f) * 4.8f;
        headOffsetY += speakingBounce;
    } else if (state == "LISTENING") {
        headTilt = 6.8f;
    }

    graphics.TranslateTransform(100.0f, 95.0f);
    graphics.RotateTransform(headTilt);
    graphics.TranslateTransform(-100.0f, -95.0f + headOffsetY);
    graphics.DrawImage(m_pHead, 0.0f, 0.0f, size, size);

    // ==========================================
    // LAYER 4: EYES (Focus / shift states)
    // ==========================================
    bool isBlinking = false;
    if (state == "IDLE")          isBlinking = (tick % 90)  < 4;
    else if (state == "THINKING") isBlinking = (tick % 35)  < 3;
    else if (state == "LISTENING")isBlinking = (tick % 200) < 3;
    else if (state == "OBSERVING")isBlinking = (tick % 100) < 4;
    else if (state == "FOCUSED")  isBlinking = (tick % 25)  < 2;
    if (isBlinking) {
        graphics.DrawImage(m_pEyesClosed, 0.0f, 0.0f, size, size);
    } else if (state == "THINKING") {
        graphics.DrawImage(m_pEyesThinking, 0.0f, 0.0f, size, size);
    } else if (state == "OBSERVING") {
        Gdiplus::GraphicsState gEyes = graphics.Save();
        float scanShiftX = sinf(tick * 0.10f) * 1.8f;
        graphics.TranslateTransform(scanShiftX, 0.0f);
        graphics.DrawImage(m_pEyesOpen, 0.0f, 0.0f, size, size);
        graphics.Restore(gEyes);
        Gdiplus::Pen scanHUD(Gdiplus::Color(160, 40, 220, 90), 1.5f);
        graphics.DrawArc(&scanHUD, 71.0f, 96.0f, 15.0f, 15.0f, (Gdiplus::REAL)((tick * 8) % 360), 180.0f);
        graphics.DrawArc(&scanHUD, 114.0f, 96.0f, 15.0f, 15.0f, (Gdiplus::REAL)((tick * 8 + 180) % 360), 180.0f);
    } else if (state == "FOCUSED") {
        Gdiplus::GraphicsState gEyes = graphics.Save();
        float readingX = sinf(tick * 0.4f) * 1.2f;
        float readingY = cosf(tick * 0.1f) * 0.5f;
        graphics.TranslateTransform(readingX, readingY);
        graphics.DrawImage(m_pEyesOpen, 0.0f, 0.0f, size, size);
        graphics.Restore(gEyes);
        Gdiplus::Pen scanHUD(Gdiplus::Color(160, 65, 120, 255), 1.5f);
        graphics.DrawArc(&scanHUD, 71.0f, 96.0f, 15.0f, 15.0f, (Gdiplus::REAL)((tick * 12) % 360), 270.0f);
        graphics.DrawArc(&scanHUD, 114.0f, 96.0f, 15.0f, 15.0f, (Gdiplus::REAL)((tick * 12 + 90) % 360), 270.0f);
    } else {
        graphics.DrawImage(m_pEyesOpen, 0.0f, 0.0f, size, size);
    }

    // ==========================================
    // LAYER 5: MOUTH (Acoustic Cadence Driven)
    // ==========================================
    if (state == "SPEAKING") {
        bool shouldMouthClose = false;
        if (!speechBubble.empty()) {
            int charIdx = (tick / 2) % (int)speechBubble.length();
            char c = speechBubble[charIdx];
            if (c == ' ' || c == '.' || c == ',' || c == '!' || c == '?' || c == '-' || c == ':') {
                shouldMouthClose = true;
            }
        }
        if (shouldMouthClose) {
            graphics.DrawImage(m_pMouthClosed, 0.0f, 0.0f, size, size);
        } else {
            int mouthPhase = (tick % 4);
            if (mouthPhase == 0)              graphics.DrawImage(m_pMouthClosed, 0.0f, 0.0f, size, size);
            else if (mouthPhase == 1 || mouthPhase == 3) graphics.DrawImage(m_pMouthHalf, 0.0f, 0.0f, size, size);
            else                              graphics.DrawImage(m_pMouthOpen,   0.0f, 0.0f, size, size);
        }
    } else if (state == "LISTENING") {
        graphics.DrawImage(m_pMouthHalf, 0.0f, 0.0f, size, size);
    } else {
        graphics.DrawImage(m_pMouthClosed, 0.0f, 0.0f, size, size);
    }

    // ==========================================
    // LAYER 6: FRONT BANGS (Foreground framing)
    // ==========================================
    graphics.DrawImage(m_pBangs, 0.0f, 0.0f, size, size);

    graphics.Restore(gHead);
    graphics.Restore(gOuterState);
}
