#pragma once
#include <windows.h>
#include <gdiplus.h>
#include <string>

class AvatarRenderer {
public:
    AvatarRenderer();
    ~AvatarRenderer();

    void initialize();
    void render(Gdiplus::Graphics& graphics, float cx, float cy, const std::string& state, int tick, float speakingBounce, float breathOffset, const std::string& speechBubble);

private:
    void loadPartAssets();
    void buildProceduralParts();

    // Dynamic 2D Layer Bitmaps
    Gdiplus::Bitmap* m_pBackHair;
    Gdiplus::Bitmap* m_pBodyTorso;
    Gdiplus::Bitmap* m_pHead;
    Gdiplus::Bitmap* m_pBangs;
    
    Gdiplus::Bitmap* m_pEyesOpen;
    Gdiplus::Bitmap* m_pEyesClosed;
    Gdiplus::Bitmap* m_pEyesThinking;
    
    Gdiplus::Bitmap* m_pMouthClosed;
    Gdiplus::Bitmap* m_pMouthOpen;
    Gdiplus::Bitmap* m_pMouthHalf;
};
