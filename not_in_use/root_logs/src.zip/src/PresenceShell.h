#pragma once

#include <windows.h>
#include <string>
#include <vector>
#include <functional>
#include <gdiplus.h>

#include "SessionState.h"

class PresenceShell {
public:
    explicit PresenceShell(SessionState& session);
    ~PresenceShell();

    bool create(HINSTANCE instance);
    void show(int cmd_show);
    int run();
    void closeShell(bool quitProcess = false);

    void setState(const std::string& stateText);
    void appendMessage(const std::string& speaker, const std::string& text, bool isVoice = false);
    void rebuildHistory(const std::vector<ChatEntry>& history);
    void postRefresh();

    // ── Phase 5 additions ─────────────────────────────────────────────────────
    void show_clarification(const std::string& question);
    void show_response(const std::string& text, const std::string& tone_hint);
    void show_safety_warning(const std::string& reason);

    // Thread-safe voice draft input bridge.
    // Use these from STT / backend threads.
    void postSetVoiceDraftText(const std::string& text);
    void postClearVoiceDraftText();
    void postCommitVoiceDraftText();

    // Optional direct UI-thread helpers.
    void setVoiceDraftText(const std::string& text);
    void clearVoiceDraftText();
    void commitVoiceDraftText();

    using ProcessCallback = std::function<std::string(const std::string&)>;
    void setProcessCallback(ProcessCallback cb) { m_processCb = std::move(cb); }

    using SyncCallback = std::function<void()>;
    void setSyncCallback(SyncCallback cb) { m_syncCb = std::move(cb); }

    using FocusCallback = std::function<void()>;
    void setFocusCallback(FocusCallback cb) { m_focusCb = std::move(cb); }

    class SubsystemControl* m_subsystems = nullptr;
    using SubsystemCallback = std::function<void()>;
    void setSubsystems(class SubsystemControl* sub) { m_subsystems = sub; }
    void setSubsystemCallback(SubsystemCallback cb) { m_subsystemCb = std::move(cb); }

    // Live server URL shown in the shell (call after MobileServer starts)
    void setServerUrl(const std::string& url);

private:
    static LRESULT CALLBACK windowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK inputEditProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

    LRESULT handleMessage(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    void onSend();
    void layoutChildren(int width, int height);
    void invalidateShell();
    void updateStateLabel();
    void applyEditTextPreservingCaret(const std::string& text);

    std::string getInputText() const;
    static std::string normalizeDraftText(const std::string& text);

private:
    HWND m_hwnd = nullptr;
    HWND m_hStateLabel = nullptr;
    HWND m_hIpLabel    = nullptr;   // shows live IP:port of MobileServer
    HWND m_hEditOutput = nullptr;
    HWND m_hEditInput  = nullptr;
    HWND m_hBtnSend = nullptr;
    HWND m_hBtnClose = nullptr;
    HWND m_hBtnMic = nullptr;
    HWND m_hBtnSpeaker = nullptr;
    HWND m_hBtnCamera = nullptr;
    HWND m_hBtnScreen = nullptr;

    // Safety veto controls
    HWND m_hBtnSafetyOK = nullptr;
    HWND m_hBtnSafetyCancel = nullptr;

    HFONT m_hFontState = nullptr;
    HFONT m_hFontChat = nullptr;

    std::string m_currentState = "IDLE";
    WNDPROC m_originalInputProc = nullptr;

    ProcessCallback m_processCb;
    SyncCallback m_syncCb;
    SubsystemCallback m_subsystemCb;
    FocusCallback m_focusCb;

    RECT m_rcInputPill {0, 0, 0, 0};
    RECT m_rcOutputArea {0, 0, 0, 0};
    RECT m_rcControlDock {0, 0, 0, 0};
    RECT m_rcClarifyPanel {0, 0, 0, 0};  // panel above input, below output

    ULONG_PTR m_gdiplusToken = 0;

    bool m_applyingProgrammaticInput = false;
    bool m_voiceDraftActive          = false;
    bool m_inLayout                  = false;  // re-entrancy guard for layoutChildren
    std::string m_voiceDraftText;
    std::string m_inputBeforeVoiceDraft;
    std::string m_serverUrl;  // cached for setServerUrl()

    // ── Phase 5 states ────────────────────────────────────────────────────────
    bool m_inClarificationMode       = false;
    std::string m_clarificationQuestion;

    bool m_safetyVetoActive          = false;
    std::string m_safetyReason;

    bool m_lastToneUrgent            = false;
    
    static constexpr COLORREF DARK_BG = RGB(16, 16, 18);
    static constexpr COLORREF DIM_TEXT = RGB(80, 80, 85);
    static constexpr COLORREF NORMAL_TEXT = RGB(210, 215, 230);

    SessionState& m_session;
};