#include "ResponseResolver.h"
#include "../database/UniversalCache.h"
#include "../database/DatabaseManager.h"
#include "../predictive/predictive_turn_engine.h"
#include <iostream>
#include <vector>

ResponseResolver& ResponseResolver::instance() {
    static ResponseResolver inst;
    return inst;
}

std::string ResponseResolver::resolve(
    const std::string& responseKey,
    const std::unordered_map<std::string, std::string>& slots,
    const std::string& requestedLang) const
{
    std::lock_guard<std::mutex> lock(cacheMutex_);
    auto& cache = UniversalCache::instance();

    const std::string defaultLang = cache.getSetting("DEFAULT_LANGUAGE", "ENGLISH");

    // Language fallback chain: requested -> default -> ENGLISH
    std::vector<std::string> langChain;
    langChain.push_back(requestedLang);
    if (requestedLang != defaultLang)
        langChain.push_back(defaultLang);
    if (defaultLang != "ENGLISH" && requestedLang != "ENGLISH")
        langChain.push_back("ENGLISH");

    for (const auto& lang : langChain) {
        auto templates = cache.getTemplates(responseKey, lang);
        if (!templates.empty())
            return injectSlots(templates[0].text, slots);
    }

    // P1 remediation fallback
    auto it = kTemplates.find(responseKey);
    if (it != kTemplates.end())
        return injectSlots(it->second, slots);

    std::cerr << "[Resolver] Missing template: " << responseKey << "\n";
    return "[" + responseKey + "]";   // safe visible fallback, never crashes
}

std::string ResponseResolver::injectSlots(
    const std::string& tmpl,
    const std::unordered_map<std::string, std::string>& slots)
{
    std::string result = tmpl;
    for (const auto& kv : slots) {
        const std::string token = "{" + kv.first + "}";
        size_t pos = 0;
        while ((pos = result.find(token, pos)) != std::string::npos) {
            result.replace(pos, token.size(), kv.second);
            pos += kv.second.size();
        }
    }
    return result;
}

std::string ResponseResolver::resolveKnowledge(const std::string& topic,
                                                float minConfidence) const {
    if (topic.empty()) return "";
    return DatabaseManager::instance().queryLearned(topic, minConfidence);
}

// Template dictionary — P1 remediation: moved from turn engine
const std::unordered_map<std::string, std::string> ResponseResolver::kTemplates = {
    {"action_ack.stop", "Understood. Stopping immediately."},
    {"language_clarify.python", "Did you mean the programming language Python?"},
    {"language_clarify.java", "Did you mean the programming language Java?"},
    {"safety_check.general", "Safety check required — are you sure you want me to do this?"},
    {"safety_check.confirm", "Before I continue — are you sure this is safe?"},
    {"fallback.clarity", "I need a bit more clarity before I can help with that."},
    {"fallback.clarity_question", "I'm having trouble following. Could you clarify what you need?"},
    {"fallback.surprise", "I need a moment to catch up — could you restate your goal?"},
    {"language_clarify.python_detail", "I can help with Python — programming, scripting, or data science?"},
    {"language_clarify.java_detail", "I can help with Java — let me know what you need."},
    {"language_clarify.general_query", "Which language did you mean? (programming, spoken, or other?)"},
    {"language_clarify.general_detail", "I need a bit more clarity about which language."},
    {"intent_clarify.general", "Before I continue, can you clarify your intent?"},
    {"dimension_clarify.entity", "which language or thing did you mean? Could you be more specific?"},
    {"fallback.unknown_topic", "I don't have enough information on that yet, but I'm learning!"},
    {"system_error.engine_uninitialized", "Predictive engine not initialized."}
};

std::string ResponseResolver::resolve(const yuki::TurnResult& turn_result) const {
    if (!turn_result.template_family.empty()) {
        std::string key = turn_result.template_family + "." + turn_result.template_slot;
        // Lookup using the key-based resolve method (checks cache, then kTemplates fallback)
        std::string resolved = resolve(key);
        if (resolved != "[" + key + "]") {
            return resolved;
        }
        if (turn_result.template_family == "dimension_clarify") {
            return "could you clarify: " + turn_result.template_slot + "?";
        }
    }
    return turn_result.requires_clarification ? turn_result.clarification_question : turn_result.response_text;
}
