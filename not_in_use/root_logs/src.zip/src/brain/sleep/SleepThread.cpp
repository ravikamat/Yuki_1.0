// SleepThread.cpp — Yuki_1.0 CMF Phase 3: Sleep Consolidation
#include "brain/sleep/SleepThread.h"
#include "brain/memory/EpisodicStore.h"
#include "brain/memory/HdcSemanticGraph.h"
#include "brain/memory/CognitiveMemoryFabric.h"
#include "brain/memory/DifferentialMemoryController.h"
#include "brain/memory/ProceduralStore.h"
#include "brain/memory/PromotionMetrics.h"
#include "brain/memory/ArchiveWriter.h"
#include "brain/inference/VariationalStateEstimator.h"
#include <iostream>
#include <chrono>

namespace yuki {
namespace sleep {

SleepThread::SleepThread(Config cfg)
    : cfg_(cfg), last_activity_(std::chrono::steady_clock::now()) {}

SleepThread::~SleepThread() { stop(); }

void SleepThread::setEpisodicStore(memory::EpisodicStore* store) { episodic_ = store; }
void SleepThread::setSemanticGraph(memory::HdcSemanticGraph* graph) { semantic_ = graph; }
void SleepThread::setVSE(inference::VariationalStateEstimator* vse) { vse_ = vse; }
void SleepThread::setCMF(memory::CognitiveMemoryFabric* cmf) { cmf_ = cmf; }

void SleepThread::start() {
    if (running_.exchange(true)) return;
    idle_ = false;
    {
        std::lock_guard<std::mutex> lk(mtx_);
        last_activity_ = std::chrono::steady_clock::now();
    }
    thread_ = std::thread(&SleepThread::run, this);
    std::cout << "[SleepThread] started (idle_threshold="
              << cfg_.idle_threshold.count() << "s)\n";
}

void SleepThread::stop() {
    running_ = false;
    cv_.notify_all();
    if (thread_.joinable()) thread_.join();
}

void SleepThread::signalActivity() {
    {
        std::lock_guard<std::mutex> lk(mtx_);
        last_activity_ = std::chrono::steady_clock::now();
    }
    if (idle_.exchange(false)) {
        cv_.notify_all();   // wake from inter-epoch sleep immediately
    }
}

DreamReport SleepThread::lastReport() const {
    std::lock_guard<std::mutex> lk(mtx_);
    return last_report_;
}

// ── Main loop ─────────────────────────────────────────────────────────────────
void SleepThread::run() {
    while (running_) {
        // Block until idle OR stop
        {
            std::unique_lock<std::mutex> lk(mtx_);
            cv_.wait_for(lk, cfg_.poll_ms, [this]() -> bool {
                if (!running_) return true;
                return (std::chrono::steady_clock::now() - last_activity_)
                        >= cfg_.idle_threshold;
            });
            if (!running_) break;
            if ((std::chrono::steady_clock::now() - last_activity_) < cfg_.idle_threshold)
                continue;
        }

        idle_ = true;
        std::cout << "[SleepThread] idle — starting dream epoch\n";

        DreamReport report = dreamEpoch();
        {
            std::lock_guard<std::mutex> lk(mtx_);
            last_report_ = report;
        }

        std::cout << "[SleepThread] epoch done:"
                  << " visited="  << report.episodes_visited
                  << " nodes="    << report.semantic_nodes_added
                  << " edges="    << report.edges_inferred
                  << " cf="       << report.counterfactuals_run
                  << " dG="       << report.avg_free_energy_delta
                  << " promo="    << report.promotions_t1_t2
                  << "/" << report.promotions_t2_t3 << "\n";

        // Inter-epoch pause — wake early on signalActivity()
        {
            std::unique_lock<std::mutex> lk(mtx_);
            cv_.wait_for(lk, cfg_.epoch_interval, [this]() {
                return !running_.load() || !idle_.load();
            });
        }
    }
}

// ── Dream Epoch ───────────────────────────────────────────────────────────────
DreamReport SleepThread::dreamEpoch() {
    DreamReport r;
    r.epoch_start = std::chrono::steady_clock::now();

    r.episodes_visited     = patternSeparation();
    r.semantic_nodes_added = r.episodes_visited;
    r.edges_inferred       = patternCompletion();
    r.counterfactuals_run  = counterfactualReplay(r.avg_free_energy_delta);
    r.precision_updates    = precisionRecalibration();
    runPromotionPolicy();          // DMC-guided T1→T2→T3 promotion (Phase B: adaptive)
    archiveEpoch();                // Phase C: dump consolidated T1 episodes to T4
    r.lsh_rehashed         = lshRehashing();
    auto [t1, t2]          = autoPromotion();
    r.promotions_t1_t2     = t1;
    r.promotions_t2_t3     = t2;

    return r;
}

// ── 1. Pattern Separation ───────────────────────────────────────────────────────────────
// Cluster T1 episodes into 5-minute time windows → create T2 concept nodes
size_t SleepThread::patternSeparation() {
    if (!episodic_ || !semantic_) return 0;
    auto snaps = episodic_->queryRecentSnapshots(cfg_.max_episodes_per_epoch, false);
    if (snaps.empty()) return 0;

    // Bias SDM writes via DMC write strategy (read-only: does not mutate inference state)
    if (cmf_) {
        auto* dmc = cmf_->differentialMemoryController();
        if (dmc) {
            // Use zero VSE/obs vectors; DMC is freshly Xavier-init (outputs ~0.5 each)
            auto strategy = dmc->decideWrite({}, {}, {});
            // strategy.write_strength / lsh_table_weights available for future integration
            (void)strategy;
        }
    }

    constexpr double WINDOW_S = 300.0;
    double bucket_start = snaps[0].timestamp;
    int    bucket_idx   = 0;
    size_t nodes_added  = 0;

    for (const auto& s : snaps) {
        if (s.timestamp - bucket_start > WINDOW_S) {
            bucket_start = s.timestamp;
            ++bucket_idx;
        }
        std::string concept = "cluster_" + std::to_string(bucket_idx)
                            + "_t" + std::to_string(static_cast<int64_t>(bucket_start));
        std::string episode = "ep_" + std::to_string(s.episode_id);
        semantic_->ingestProposition(concept, "contains", episode, 0.8f);
        episodic_->markConsolidated(s.episode_id);
        nodes_added++;
    }
    return nodes_added;
}

// ── 2. Pattern Completion ─────────────────────────────────────────────────────
// Compute pairwise co-occurrence for top T2 concepts → ingest causal edges
size_t SleepThread::patternCompletion() {
    if (!episodic_ || !semantic_) return 0;
    auto concepts = semantic_->getAllConcepts(50);
    if (concepts.size() < 2) return 0;

    size_t edges = 0;
    const size_t max_pairs = 20;   // guard O(N²) blowup
    for (size_t i = 0; i < concepts.size() && i < max_pairs; ++i) {
        for (size_t j = i + 1; j < concepts.size() && j < max_pairs; ++j) {
            float cooc = episodic_->computeCooccurrence(
                concepts[i].name, concepts[j].name, 300'000LL); // 5-min window ms
            if (cooc >= cfg_.cooccurrence_threshold) {
                std::string rel = (cooc > 0.6f)
                    ? "strongly_associated" : "co_occurs_with";
                semantic_->ingestProposition(
                    concepts[i].name, rel, concepts[j].name, cooc);
                edges++;
            }
        }
    }
    return edges;
}

// ── 3. Counterfactual Replay ──────────────────────────────────────────────────
// Simulate alt policies on recent episodes using VSE's FEC; compute ΔG
size_t SleepThread::counterfactualReplay(float& avg_delta_out) {
    avg_delta_out = 0.0f;
    if (!vse_) return 0;
    if (!episodic_) return 0;

    auto snaps = episodic_->queryRecentSnapshots(
        cfg_.max_counterfactuals_per_epoch, true);
    if (snaps.empty()) return 0;

    // Copy belief state — simulation must NOT mutate live VSE
    auto belief_copy = vse_->currentBelief();
    auto& fec   = vse_->freeEnergyCalculator();
    auto& model = vse_->generativeModel();

    // 5 canonical policies spanning the parameter space
    std::vector<inference::Policy> policies(5);
    for (int p = 0; p < 5; ++p) {
        policies[p].parameters.resize(8, 0.5f);
        policies[p].parameters[0] = 0.2f + p * 0.15f;   // responseLength
        policies[p].parameters[4] = p * 0.25f;           // proactivity
        policies[p].description   = "cf_" + std::to_string(p);
    }

    float total_delta = 0.0f;
    size_t count = 0;
    for (const auto& s : snaps) {
        int actual_idx = static_cast<int>(
            (s.vector_slot >= 0 ? s.vector_slot : 0) % 5);
        float g_actual = fec.computeG(policies[actual_idx], belief_copy, model);
        float g_best   = g_actual;
        for (int p = 0; p < 5; ++p) {
            if (p == actual_idx) continue;
            float g = fec.computeG(policies[p], belief_copy, model);
            if (g < g_best) g_best = g;
        }
        total_delta += (g_best - g_actual);   // ≤ 0 means improvement possible
        count++;
    }
    avg_delta_out = count > 0 ? total_delta / count : 0.0f;
    return count;
}

// ── 4. Precision Recalibration ────────────────────────────────────────────────
// Report consolidation signal as a proxy outcome for PrecisionEngine
size_t SleepThread::precisionRecalibration() {
    if (!vse_) return 0;
    auto& pe = vse_->precisionEngine();

    // Use consolidation ratio as rough accuracy proxy
    auto consolidated   = episodic_->queryRecentSnapshots(50, true);
    auto unconsolidated = episodic_->queryRecentSnapshots(50, false);
    float total = static_cast<float>(consolidated.size() + unconsolidated.size());
    bool good = total > 0 && (consolidated.size() / total) > 0.5f;

    pe.updateHistoricalAccuracy("sleep_t1_consolidation", good);
    pe.updateHistoricalAccuracy("sleep_semantic_coverage", good);
    return 2;
}

// ── 5. LSH Rehashing ─────────────────────────────────────────────────────────
// Rebuild LSH tables if collision rate is degraded
bool SleepThread::lshRehashing() {
    if (!episodic_) return false;
    if (episodic_->getLshCollisionRate() > 0.5f) {
        episodic_->rebuildLshTables();
        return true;
    }
    return false;
}

// ── 6. Auto-Promotion ────────────────────────────────────────────────────────
// T1 → T2: reinforce frequently-visited episodes; T2 → T3: mark procedural
std::pair<size_t,size_t> SleepThread::autoPromotion() {
    if (!episodic_ || !semantic_) return {0, 0};
    size_t t1_t2 = 0, t2_t3 = 0;

    // T1 → T2: episodes with high access_count
    auto snaps = episodic_->queryRecentSnapshots(100, false);
    for (const auto& s : snaps) {
        if (s.access_count >= static_cast<int>(cfg_.promotion_access_min)) {
            semantic_->reinforce("ep_" + std::to_string(s.episode_id));
            episodic_->markConsolidated(s.episode_id);
            t1_t2++;
        }
    }

    // T2 → T3: heavily reinforced concepts
    auto concepts = semantic_->getAllConcepts(200);
    for (const auto& c : concepts) {
        if (c.access_count >= static_cast<int>(cfg_.promotion_reinf_min * 2.0f)
            && c.type != "procedural") {
            semantic_->markProcedural(c.name);
            t2_t3++;
        }
    }

    return {t1_t2, t2_t3};
}

// ── 7. DMC-guided Promotion Policy ───────────────────────────────────────────────
// Phase B: Adaptive promotion policy — PromotionMetrics decay * adaptive thresholds.
void SleepThread::runPromotionPolicy() {
    if (!cmf_) return;
    auto* dmc      = cmf_->differentialMemoryController();
    auto* episodic = cmf_->episodicStore();
    auto* semantic = cmf_->hdcSemanticGraph();
    auto* t3       = cmf_->proceduralStore();
    if (!dmc || !episodic || !semantic) return;

    const double now_hours = static_cast<double>(
        std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::system_clock::now().time_since_epoch()).count()) / 3600.0;

    auto eStats    = episodic->getAllMemoryStats();
    auto cStats    = semantic->getAllConceptStats();
    auto decisions = dmc->evaluatePromotions(eStats, cStats);

    // Build PromotionMetrics for episodic candidates
    std::vector<memory::PromotionMetrics> eMetrics;
    eMetrics.reserve(eStats.size());
    for (const auto& s : eStats) {
        memory::PromotionMetrics m;
        m.id                    = s.id;
        m.access_count          = s.accessCount;
        m.reinforcement_count   = s.reinforcementCount;
        m.last_access_timestamp = 0;
        m.created_at_hours      = s.ageHours;
        eMetrics.push_back(m);
    }

    const double t1_thresh = memory::PromotionMetrics::adaptiveT1Threshold(eStats.size());
    const double t2_thresh = memory::PromotionMetrics::adaptiveT2Threshold(cStats.size());

    for (size_t i = 0; i < decisions.size(); ++i) {
        const auto& d = decisions[i];
        double adjusted_t1 = static_cast<double>(d.t1_to_t2_score);
        double adjusted_t2 = static_cast<double>(d.t2_to_t3_score);
        if (i < eMetrics.size())
            adjusted_t1 *= eMetrics[i].decayedStrength(0.01, now_hours);

        if (d.isEpisodic && adjusted_t1 > t1_thresh) {
            semantic->ingestProposition(d.memoryId, "promoted_from_episodic");
            episodic->resetReinforcement(d.memoryId);
        }
        if (!d.isEpisodic && adjusted_t2 > t2_thresh && t3) {
            auto blob      = compileConceptToBlob(d.memoryId);
            auto embedding = semantic->getConceptEmbedding(d.memoryId);
            t3->storeSkill(d.memoryId, blob, embedding);
            semantic->markProcedural(d.memoryId);
            semantic->resetReinforcement(d.memoryId);
        }
    }
}

// Minimal serialization: concept name as UTF-8 bytes
std::vector<uint8_t> SleepThread::compileConceptToBlob(const std::string& name) {
    return std::vector<uint8_t>(name.begin(), name.end());
}

// Phase C: Archive consolidated T1 episodes to a .yuk archive file (one per epoch).
void SleepThread::archiveEpoch() {
    if (!cmf_) return;
    auto* archive  = cmf_->archiveWriter();
    auto* episodic = cmf_->episodicStore();
    if (!archive || !episodic) return;

    auto snaps = episodic->queryRecentSnapshots(
        cfg_.max_episodes_per_epoch, /*consolidated_only=*/true);
    if (snaps.empty()) return;

    static const std::vector<memory::ColumnarArchiveFormat::ColumnSchema> kSchema = {
        { "episode_id", memory::ColumnarArchiveFormat::ColumnSchema::Type::INT64  },
        { "timestamp",  memory::ColumnarArchiveFormat::ColumnSchema::Type::DOUBLE },
        { "slot",       memory::ColumnarArchiveFormat::ColumnSchema::Type::INT64  }
    };

    uint64_t ts = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
    std::string archive_name = "epoch_" + std::to_string(ts);

    if (!archive->beginArchive(archive_name, kSchema)) return;

    std::vector<int64_t> ids;
    std::vector<double>  timestamps;
    std::vector<int64_t> slots;
    ids.reserve(snaps.size());
    timestamps.reserve(snaps.size());
    slots.reserve(snaps.size());
    for (const auto& s : snaps) {
        ids.push_back(s.episode_id);
        timestamps.push_back(s.timestamp);
        slots.push_back(s.vector_slot);
    }

    std::vector<memory::ColumnarArchiveFormat::ColumnData> rg;
    rg.push_back({ "episode_id", ids        });
    rg.push_back({ "timestamp",  timestamps });
    rg.push_back({ "slot",       slots      });
    archive->writeRowGroup(rg);

    std::string merkle_root;
    archive->finalizeArchive(merkle_root);
}

} // namespace sleep
} // namespace yuki
