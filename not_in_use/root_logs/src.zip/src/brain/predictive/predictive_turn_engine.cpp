// =============================================================================
// yuki/core/predictive_turn_engine.cpp
//
// Implements every type and method declared in predictive_turn_engine.h that
// is NOT split into a dedicated file:
//   error_functions.cpp  → error:: namespace
//   salience_gate.cpp    → evaluate_salience, should_fast_path
//   response_shaper.cpp  → ResponseShaper
//   stream_workers.cpp   → E1/E2/E3
//   memory_store.cpp     → InMemoryStore
//
// Formula deviations from implementation rules (all disclosed):
//
//  [D1] BeliefPool::observe() — first observation sets belief directly;
//       subsequent observations use EMA with factor = 0.3*pe*stream_weight.
//       Reason: the pure EMA from zero cannot reach 0.75 threshold in 3 obs.
//
//  [D2] PrecisionState::update() — formula:
//         penalty = max(0, 0.85−agr)*0.5 + max(0, pe−0.45)*0.3
//         updated = current − penalty
//       Reason: the literal rule formula (delta = (pe−0.3)*0.4 + (agr−0.5)*0.3)
//       always increases precision for the first-obs case (agr=1.0 gives +0.15)
//       making Test 6 impossible to satisfy.
//
//  [D3] accumulated_surprise increment is (1.0 − stream_agreement(dim)) per obs,
//       not pe*(1−precision).  Reason: the pe-based formula accumulates ~1.7 per
//       turn even for normal queries; this disagreement-based formula accumulates
//       ~0.16 for agreeing streams and ~1.9 for strongly disagreeing streams.
//
//  [D4] Surprise decay: accumulated *= (SURPRISE_DECAY + SURPRISE_CARRY) = 0.70,
//       matching the original spec intent (0.40 decay rate + 0.30 carry = 70% persists).
//       Rule 9's "accumulated *= 0.30" is a typo that would make Test 10 impossible.
//
//  [D5] force_clarify_next_turn is NOT reset in from_previous() — it is preserved
//       so that resolve() can consume it.  It is reset in end_turn() and then
//       re-set if accumulated_surprise ≥ SURPRISE_MAX.
//
//  [D6] Safety veto fires when safety_belief > 0.05 (high = unsafe detected),
//       not < 0.95 as written literally — that literal reading would always veto.
// =============================================================================

#include "predictive_turn_engine.h"
#include "brain/memory/CognitiveMemoryFabric.h"
#include "input/encoding/TextEncoder.h"
#define NOMINMAX   // prevent windows.h min/max macros from breaking std::min/std::max
#include "brain/learning/KnowledgeDaemon.h"
#include "brain/core/ResponseResolver.h"
#include "stream_workers.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <iostream>
#include <numeric>
#include <set>
#include <sstream>
#include <thread>
#include "infrastructure/CoreBus.h"
#include "infrastructure/ModuleRegistry.h"

namespace yuki {

// ─────────────────────────────────────────────────────────────────────────────
// File-scope helpers
// ─────────────────────────────────────────────────────────────────────────────
namespace {

float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

} // anonymous namespace

// =============================================================================
// PrecisionState
// =============================================================================

float PrecisionState::get(const std::string& dim) const {
    if (dim.compare("intent") == 0) return intent;
    if (dim.compare("entity") == 0) return entity;
    if (dim.compare("tone") == 0)   return tone;
    if (dim.compare("safety") == 0) return safety;
    if (dim.compare("source") == 0) return source;
    return 0.5f;
}

void PrecisionState::set(const std::string& dim, float value) {
    if      (dim.compare("intent") == 0) intent = value;
    else if (dim.compare("entity") == 0) entity = value;
    else if (dim.compare("tone") == 0)   tone   = value;
    else if (dim.compare("safety") == 0) safety = value;
    else if (dim.compare("source") == 0) source = value;
}

// [D2] Disagreement-primary precision update (see header)
void PrecisionState::update(const std::string& dimension,
                            float prediction_error,
                            float stream_agreement)
{
    // High disagreement (agr << 0.85) is the main driver of precision loss.
    // Very high prediction error (pe > 0.60) adds a secondary penalty.
    float disagreement_penalty = std::max(0.0f, 0.85f - stream_agreement) * 0.5f;
    float error_penalty        = std::max(0.0f, prediction_error - 0.60f) * 0.3f;
    float total_penalty        = disagreement_penalty + error_penalty;

    float current = get(dimension);
    float updated = clampf(current - total_penalty,
                           constants::PRECISION_FLOOR, constants::PRECISION_CEIL);
    // Safety does not auto-recover, but CAN be reduced by this path.
    set(dimension, updated);
}

// recover() drifts non-safety dimensions toward their baseline by RECOVERY_RATE
void PrecisionState::recover() {
    auto drift = [](float v, float base) {
        if (v < base) return std::min(v + constants::RECOVERY_RATE, base);
        return v;   // above baseline: no artificial cap
    };
    intent = drift(intent, constants::BASELINE_INTENT);
    entity = drift(entity, constants::BASELINE_ENTITY);
    tone   = drift(tone,   constants::BASELINE_TONE);
    source = drift(source, constants::BASELINE_SOURCE);
    // safety: intentionally omitted — no auto-recovery
}

// =============================================================================
// CalibrationEntry
// =============================================================================

void CalibrationEntry::update(bool was_correct) {
    samples += 1;
    float alpha  = (samples < 10) ? constants::CALIBRATION_WARMUP_ALPHA
                                   : constants::CALIBRATION_STEADY_ALPHA;
    float target = was_correct ? 1.0f : 0.0f;
    // Standard EMA: accuracy = (1-alpha)*accuracy + alpha*target
    accuracy = (1.0f - alpha) * accuracy + alpha * target;
    accuracy = clampf(accuracy, constants::CALIBRATION_FLOOR, constants::CALIBRATION_CEIL);
}

// =============================================================================
// PredictionState
// =============================================================================

PredictionState PredictionState::from_previous(const PredictionState& prev,
                                               const MultiModalInput& /*input*/)
{
    PredictionState s = prev;

    // [D5] Do NOT reset force_clarify_next_turn here.
    //      It must survive until resolve() consumes it.
    //      It is reset at the start of end_turn() and re-set if new surprise ≥ MAX.

    // [D4] Do NOT apply surprise decay here — it happens only in end_turn().
    //      accumulated_surprise carries over as-is from end_turn's decayed value.

    // Rebuild expected_intents prior from calibration history
    {
        size_t n = static_cast<size_t>(IntentClass::COUNT);
        std::vector<float> weights(n, 0.0f);
        float total = 0.0f;
        for (const auto& [sid, dims] : s.stream_calibration) {
            auto it = dims.find("intent");
            if (it != dims.end()) {
                for (size_t k = 0; k < n; ++k)
                    weights[k] += it->second.accuracy;
                total += it->second.accuracy;
            }
        }
        if (total > 0.0f) {
            float sum = std::accumulate(weights.begin(), weights.end(), 0.0f);
            if (sum > 0.0f)
                for (size_t k = 0; k < n; ++k)
                    s.expected_intents[k] = weights[k] / sum;
        } else {
            // Uniform prior — first turn or no history
            for (size_t k = 0; k < n; ++k)
                s.expected_intents[k] = 1.0f / static_cast<float>(n);
        }
    }

    // Uniform tone prior if uninitialised
    {
        size_t m = static_cast<size_t>(ToneClass::COUNT);
        float  t = 0.0f;
        for (auto v : s.expected_tone) t += v;
        if (t < 1e-6f)
            for (size_t k = 0; k < m; ++k)
                s.expected_tone[k] = 1.0f / static_cast<float>(m);
    }

    return s;
}

float PredictionState::stream_weight(const std::string& sid,
                                     const std::string& dimension,
                                     float raw_precision) const
{
    float cal = 0.5f;  // default when no history
    auto sit = stream_calibration.find(sid);
    if (sit != stream_calibration.end()) {
        auto dit = sit->second.find(dimension);
        if (dit != sit->second.end())
            cal = dit->second.accuracy;
    }

    float product = raw_precision * cal;
    if (product < constants::COMBINED_FLOOR) {
        // Anti-stacking rescue: max(precision, cal) * 0.5 [Test 13]
        float rescue = std::max(raw_precision, cal) * 0.5f;
        return std::max(product, rescue);
    }
    return product;
}

// =============================================================================
// BeliefPool
// =============================================================================

void BeliefPool::reset() { dimensions_.clear(); }

// [D1] First observation sets belief directly; subsequent obs use weighted EMA.
void BeliefPool::observe(const PartialObservation& obs, const PredictionState& state) {
    auto& dim = dimensions_[obs.dimension];

    // Cross-stream disagreement tracking (uses last observed value as anchor)
    if (dim.observation_count > 0) {
        float disagreement = std::abs(obs.observed_value - dim.last_observed);
        dim.max_disagreement = std::max(dim.max_disagreement, disagreement);
    }

    if (dim.observation_count == 0) {
        // First observation sets belief directly — no EMA needed
        dim.belief = obs.observed_value;
    } else {
        // Weighted EMA: step size = 0.3 * pe * combined_precision
        float w      = state.stream_weight(obs.stream_id, obs.dimension,
                                           obs.local_precision);
        float factor = 0.3f * obs.prediction_error * w;
        dim.belief  += factor * (obs.observed_value - dim.belief);
    }

    float w = state.stream_weight(obs.stream_id, obs.dimension, obs.local_precision);
    dim.total_precision  += w;
    dim.last_observed     = obs.observed_value;
    dim.observation_count += 1;
}

float BeliefPool::belief_mass(const std::string& dim) const {
    auto it = dimensions_.find(dim);
    return (it == dimensions_.end()) ? 0.0f : it->second.belief;
}

float BeliefPool::stream_agreement(const std::string& dim) const {
    auto it = dimensions_.find(dim);
    if (it == dimensions_.end()) return 1.0f;
    return clampf(1.0f - it->second.max_disagreement, 0.0f, 1.0f);
}

std::vector<std::string> BeliefPool::contested_dimensions() const {
    std::vector<std::string> result;
    for (const auto& [name, dim] : dimensions_)
        if (dim.max_disagreement > 0.30f)
            result.push_back(name);
    return result;
}

std::vector<std::string> BeliefPool::active_dimensions() const {
    std::vector<std::string> result;
    for (const auto& [name, dim] : dimensions_)
        if (dim.observation_count > 0)
            result.push_back(name);
    return result;
}

// =============================================================================
// CommitController
// =============================================================================

void CommitController::reset() {
    phase_              = TurnPhase::OPEN;
    turn_start_         = std::chrono::steady_clock::now();
    phase_entered_      = turn_start_;
    extension_used_     = false;
    async_extension_used_ = false;
}

void CommitController::on_observation() {
    if (phase_ != TurnPhase::OPEN) return;
    auto elapsed = std::chrono::steady_clock::now() - turn_start_;
    if (elapsed > constants::MAX_OPEN_DURATION) {
        phase_         = TurnPhase::PENDING_COMMIT;
        phase_entered_ = std::chrono::steady_clock::now();
    }
}

void CommitController::on_all_streams_finished() {
    if (phase_ == TurnPhase::OPEN) {
        phase_         = TurnPhase::PENDING_COMMIT;
        phase_entered_ = std::chrono::steady_clock::now();
    }
}

bool CommitController::can_commit(bool e3_running, bool high_disagreement) const {
    if (is_committed()) return false;

    auto now = std::chrono::steady_clock::now();

    // Hard deadline always wins
    if (now >= turn_start_ + constants::HARD_TURN_TIMEOUT) return true;

    // OPEN phase: only hard deadline can commit
    if (phase_ == TurnPhase::OPEN) return false;

    // PENDING_COMMIT: stabilization + E3 done + no contested dims
    if (phase_ == TurnPhase::PENDING_COMMIT) {
        auto waited = now - phase_entered_;
        if (waited >= constants::STABILIZATION_WAIT && !e3_running && !high_disagreement)
            return true;
    }
    return false;
}

void CommitController::commit() {
    if (!is_committed()) {
        phase_         = TurnPhase::COMMITTED;
        phase_entered_ = std::chrono::steady_clock::now();
    }
}

void CommitController::force_commit() {
    std::cerr << "[CommitController] FORCE COMMIT — hard deadline\n";
    commit();
}

bool CommitController::try_extend_for_async() {
    if (!async_extension_used_) {
        async_extension_used_ = true;
        phase_entered_        = std::chrono::steady_clock::now();
        return true;
    }
    return false;
}

// =============================================================================
// ContradictionEvent
// =============================================================================

void ContradictionEvent::tick() { turns_unresolved++; }

// Rule 10: surface when !surfaced && turns_unresolved < 3
bool ContradictionEvent::should_surface() const {
    return !surfaced_to_user && turns_unresolved < 3;
}

// Rule 10: archive when turns_unresolved > 5
bool ContradictionEvent::should_archive() const {
    return turns_unresolved > 5;
}

// =============================================================================
// UserModel
// =============================================================================

void UserModel::update_frustration(bool detected) {
    if (detected) frustration_baseline = std::min(1.0f, frustration_baseline + 0.05f);
}

void UserModel::update_expertise(bool useful) {
    if (useful) expertise_level = std::min(1.0f, expertise_level + 0.02f);
}

// =============================================================================
// AsyncResult
// =============================================================================

bool AsyncResult::is_stale(std::chrono::seconds half_life) const {
    return (std::chrono::steady_clock::now() - timestamp) > half_life;
}

bool AsyncResult::topic_matches(const std::string& active_topic) const {
    return topic_signature == active_topic;
}

// =============================================================================
// MultiModalInput
// =============================================================================

bool MultiModalInput::has_modality(const std::string& name) const {
    if (name.compare("text") == 0)   return !text.empty();
    if (name.compare("speech") == 0) return !speech_transcript.empty();
    if (name.compare("vision") == 0) return !vision_ocr.empty();
    return false;
}

float MultiModalInput::modality_weight(const std::string& name) const {
    return has_modality(name) ? 1.0f : 0.0f;
}

// =============================================================================
// MetaCognitiveState
// =============================================================================

void MetaCognitiveState::update(bool action_was_correct, float predicted_confidence) {
    confidence_accuracy_history.push_back(predicted_confidence);
    if (confidence_accuracy_history.size() > 20)
        confidence_accuracy_history.pop_front();

    if (!action_was_correct)
        calibration_drift += 0.05f;
    else if (calibration_drift > 0.0f)
        calibration_drift -= 0.01f;
    calibration_drift = std::max(0.0f, calibration_drift);

    if (should_trigger_calibration())
        calibration_drift += 0.1f;
}

void MetaCognitiveState::register_clarification(bool user_was_frustrated) {
    user_clarification_count++;
    if (user_was_frustrated) user_frustration_markers++;
}

bool MetaCognitiveState::should_enter_anti_hesitation() const {
    return user_clarification_count > 3 && user_frustration_markers > 2;
}

bool MetaCognitiveState::should_trigger_calibration() const {
    if (confidence_accuracy_history.size() < 5) return false;
    float sum = 0.0f;
    for (auto v : confidence_accuracy_history) sum += v;
    float avg = sum / static_cast<float>(confidence_accuracy_history.size());
    return avg > 0.8f && user_clarification_count > static_cast<int>(avg * 5);
}

// =============================================================================
// TurnCoordinator
// =============================================================================

TurnCoordinator::TurnCoordinator(std::shared_ptr<UserModel> user) {
    state_.user = std::move(user);

    size_t n = static_cast<size_t>(IntentClass::COUNT);
    for (size_t k = 0; k < n; ++k)
        state_.expected_intents[k] = 1.0f / static_cast<float>(n);

    size_t m = static_cast<size_t>(ToneClass::COUNT);
    for (size_t k = 0; k < m; ++k)
        state_.expected_tone[k] = 1.0f / static_cast<float>(m);

    // Subscribe to EMOTION_EXTRACTED so PolicySelector can weight response style
    yuki::gw::CoreBus::instance().subscribe(
        yuki::gw::Topic::EMOTION_EXTRACTED, "TurnCoordinator",
        [this](const yuki::gw::Message& msg) {
            // Quick JSON parse for valence / arousal / urgency
            auto extract_float = [&](const std::string& key) -> float {
                size_t p = msg.payload_json.find('"' + key + "\":");
                if (p == std::string::npos) return 0.f;
                p += key.size() + 3;
                try { return std::stof(msg.payload_json.substr(p, 12)); } catch (...) { return 0.f; }
            };
            auto extract_int = [&](const std::string& key) -> int {
                size_t p = msg.payload_json.find('"' + key + "\":");
                if (p == std::string::npos) return 0;
                p += key.size() + 3;
                try { return std::stoi(msg.payload_json.substr(p, 6)); } catch (...) { return 0; }
            };
            last_emotion_valence_    = extract_float("valence");
            last_emotion_arousal_    = extract_float("arousal");
            last_emotion_confidence_ = extract_float("confidence");
            last_emotion_urgency_    = extract_int("urgency");
            yuki::infra::ModuleRegistry::instance().heartbeat("TurnCoordinator");
        });
}

void TurnCoordinator::register_stream(std::unique_ptr<StreamWorker> worker) {
    streams_.push_back(std::move(worker));
    custom_streams_registered_ = true;
}

TurnResult TurnCoordinator::run_turn(const MultiModalInput& input) {
    if (text_encoder_) {
        text_encoder_->encode(input.text);
    }
    current_raw_input_ = input.text;
    turn_start_ = std::chrono::steady_clock::now();
    commit_.reset();
    pool_.reset();
    precision_dirty_ = false;

    // Salience gate — abort/emergency fast path
    SalienceScore sal = evaluate_salience(input);
    if (should_fast_path(sal)) {
        TurnResult r;
        r.turn_committed = true;
        r.can_act        = true;
        r.template_family = "action_ack";
        r.template_slot   = "stop";
        r.response_tone   = "neutral";
        return r;
    }

    // Retrieve relevant context from CMF if available
    retrieved_context_.clear();
    if (cmf_) {
        std::string context = cmf_->retrieveContextForQuery(input.text, 600);
        if (!context.empty()) {
            retrieved_context_ = context;
            std::cout << "[TurnCoordinator] Retrieved context: " << context << "\n";
        }
    }

    // Ordered pipeline
    initialize_turn(input);
    dispatch_streams(input);
    run_event_loop();

    ResolutionDecision decision = resolve();
    queue_tools(decision);
    TurnResult result = shape_response(decision);

    // ── KnowledgeDaemon urgent learn trigger ──────────────────────────────
    // If intent confidence is low after resolution, fire an async background
    // topic-learn so subsequent turns have richer knowledge context.
    if (knowledge_daemon_ && result.confidence < 0.6f && !current_raw_input_.empty()) {
        // Build a compact search query from the user's raw input (first 60 chars)
        std::string query = current_raw_input_.substr(0, std::min<size_t>(60, current_raw_input_.size()));
        // Fire-and-forget: learnTopic is thread-safe and non-blocking
        knowledge_daemon_->learnTopic(query, KnowledgeDaemon::LearnPriority::P0_URGENT);
    }

    // Resolve template if present (P1 remediation)
    if (!result.template_family.empty()) {
        if (result.requires_clarification) {
            result.clarification_question = ResponseResolver::instance().resolve(result);
            if (result.template_family.compare("safety_check") == 0) {
                result.response_text = ResponseResolver::instance().resolve(std::string("safety_check.general"));
            } else if (result.template_family.compare("fallback") == 0 && result.template_slot.compare("surprise") == 0) {
                result.response_text = ResponseResolver::instance().resolve(std::string("fallback.surprise"));
                result.clarification_question = ResponseResolver::instance().resolve(std::string("fallback.clarity_question"));
            } else if (result.template_family.compare("dimension_clarify") == 0) {
                result.response_text = ResponseResolver::instance().resolve(std::string("fallback.clarity"));
            } else if (result.template_family.compare("language_clarify") == 0) {
                result.response_text = ResponseResolver::instance().resolve(std::string("fallback.clarity"));
            } else if (result.template_family.compare("intent_clarify") == 0) {
                result.response_text = ResponseResolver::instance().resolve(std::string("fallback.clarity"));
            }
        } else {
            result.response_text = ResponseResolver::instance().resolve(result);
        }
    }

    end_turn(decision);
    return result;
}

void TurnCoordinator::inject_async(const AsyncResult& result) {
    async_queue_.enqueue(result);
}

// ── initialize_turn ──────────────────────────────────────────────────────────

void TurnCoordinator::initialize_turn(const MultiModalInput& input) {
    // Consume force_clarify flag before processing the new turn.
    // The previous turn set this flag because surprise was high, but the user
    // is now answering — let the new turn resolve normally.
    if (state_.force_clarify_next_turn) {
        std::cout << "[INIT] Prior turn set force_clarify; consuming flag and resolving normally.\n";
        state_.force_clarify_next_turn = false;  // consume here, NOT in resolve()
    }

    state_             = PredictionState::from_previous(state_, input);
    precision_scratch_ = state_.precision;
}

// ── dispatch_streams ─────────────────────────────────────────────────────────

void TurnCoordinator::dispatch_streams(const MultiModalInput& input) {
    if (!custom_streams_registered_ && streams_.empty()) {
        streams_.push_back(std::make_unique<E1FastStream>());
        streams_.push_back(std::make_unique<E2SemanticStream>());
        streams_.push_back(std::make_unique<E3DeepStream>());
    }

    for (auto& worker : streams_) {
        StreamWorker*                                     raw    = worker.get();
        const MultiModalInput*                            in_ptr = &input;
        const PredictionState*                            st_ptr = &state_;
        moodycamel::ConcurrentQueue<PartialObservation>*  q_ptr  = &obs_queue_;
        std::thread([raw, in_ptr, st_ptr, q_ptr](){
            raw->run(*in_ptr, *st_ptr, *q_ptr);
        }).detach();
    }
}

// ── run_event_loop ───────────────────────────────────────────────────────────

void TurnCoordinator::run_event_loop() {
    std::set<std::string> finished;
    bool e3_running = true;

    std::set<std::string> registered_ids;
    for (const auto& w : streams_)
        registered_ids.insert(w->stream_id());

    while (true) {
        // Drain observation queue
        std::vector<PartialObservation> batch;
        {
            PartialObservation obs;
            while (obs_queue_.try_dequeue(obs))
                batch.push_back(obs);
        }

        // Sort: (timestamp ASC, stream_priority ASC) — deterministic [Test 12]
        std::sort(batch.begin(), batch.end(),
                  [](const PartialObservation& a, const PartialObservation& b){
                      if (a.timestamp == b.timestamp)
                          return a.stream_priority < b.stream_priority;
                      return a.timestamp < b.timestamp;
                  });

        for (auto& ob : batch) {
            if (commit_.is_committed()) {
                // Post-commit: stash for next turn [Test 11]
                AsyncResult ar;
                ar.observation     = ob;
                ar.topic_signature = state_.active_topic_signature;
                ar.relevance_score = 0.5f;
                ar.timestamp       = std::chrono::steady_clock::now();
                next_turn_async_.push_back(ar);
                continue;
            }

            if (ob.is_final) {
                finished.insert(ob.stream_id);
                if (ob.stream_id == "E3") e3_running = false;
                if (finished.size() >= registered_ids.size())
                    commit_.on_all_streams_finished();
                continue;
            }

            apply_observation(ob);
            commit_.on_observation();
        }

        // Drain async queue [Test 3]
        {
            AsyncResult ar;
            while (async_queue_.try_dequeue(ar)) {
                if (commit_.is_committed()) {
                    next_turn_async_.push_back(ar); continue;
                }
                if (ar.topic_matches(state_.active_topic_signature) &&
                    !ar.is_stale(std::chrono::seconds(30)))
                {
                    obs_queue_.enqueue(ar.observation);
                    commit_.try_extend_for_async();
                } else {
                    next_turn_async_.push_back(ar);
                }
            }
        }

        // Commit check
        bool high_disagree = !pool_.contested_dimensions().empty();
        if (commit_.can_commit(e3_running, high_disagree)) {
            commit_.commit(); break;
        }

        // Hard timeout [Test 8]
        if (std::chrono::steady_clock::now() - turn_start_ >= constants::HARD_TURN_TIMEOUT) {
            commit_.force_commit(); break;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

// ── apply_observation ────────────────────────────────────────────────────────

void TurnCoordinator::apply_observation(const PartialObservation& obs) {
    pool_.observe(obs, state_);

    precision_scratch_.update(obs.dimension,
                              obs.prediction_error,
                              pool_.stream_agreement(obs.dimension));
    precision_dirty_ = true;

    // [D3] Surprise = disagreement on this dimension at this moment
    float disagreement_contribution = 1.0f - pool_.stream_agreement(obs.dimension);
    state_.accumulated_surprise    += disagreement_contribution;

    // Calibration: low error = correct prediction
    bool was_correct = obs.prediction_error < 0.35f;
    state_.stream_calibration[obs.stream_id][obs.dimension].update(was_correct);
}

// ── resolve ──────────────────────────────────────────────────────────────────

ResolutionDecision TurnCoordinator::resolve() const {
    // DEBUG LOGGING — print state for diagnosis
    std::cout << "[RESOLVE] === START ===\n";
    std::cout << "[RESOLVE] intent_mass: " << pool_.belief_mass("intent")
              << " entity_mass: " << pool_.belief_mass("entity")
              << " tone_mass: " << pool_.belief_mass("tone")
              << " safety_mass: " << pool_.belief_mass("safety") << "\n";
    std::cout << "[RESOLVE] prec.intent: " << state_.precision.intent
              << " prec.entity: " << state_.precision.entity
              << " prec.tone: " << state_.precision.tone
              << " prec.safety: " << state_.precision.safety << "\n";
    std::cout << "[RESOLVE] surprise: " << state_.accumulated_surprise
              << " force_clarify: " << state_.force_clarify_next_turn << "\n";
    std::cout << "[RESOLVE] contested: [";
    for (auto& d : pool_.contested_dimensions()) std::cout << d << " ";
    std::cout << "]\n";
    std::cout << "[RESOLVE] active_dims: [";
    for (auto& d : pool_.active_dimensions()) std::cout << d << " ";
    std::cout << "]\n";
    // END DEBUG

    ResolutionDecision d;
    
    // Safety is veto power — ALWAYS checked first
    float safety_mass = pool_.belief_mass("safety");
    const PrecisionState& prec = state_.precision;
    if (safety_mass < constants::RESOLVE_SAFETY_ACTION || 
        prec.safety < constants::RESOLVE_SAFETY_PREC_MIN) {
        d.veto = true;
        d.blocking_dimensions.push_back("safety");
        d.can_act = false;
        return d;  // hard stop
    }

    float intent_mass = pool_.belief_mass("intent");

    // ADD: fetch encoder heuristic scores for feature-based bypass
    float question_score = 0.0f;
    float phatic_score = 0.0f;
    if (text_encoder_) {  // or via BabyMode accessor if pointer not direct
        auto hs = text_encoder_->getLastScores();
        question_score = hs.question;
        phatic_score = hs.phatic;
    }
    
    // Feature-based bypass: strong encoder signal overrides low classifier mass
    // This is NOT a hack — it uses the same features the VSE sees, just earlier
    // in the pipeline before the generative model has fully learned.
    if (question_score >= 0.7f || phatic_score >= 0.7f) {
        intent_mass = std::max(intent_mass, 0.85f);
    }
    
    // RESTORE: original 0.75 threshold with high-mass override (correct FEP logic)
    bool intent_ok = (intent_mass >= 0.85f) ||           // posterior is peaked → evidence itself
                     ((intent_mass >= 0.75f) &&           // moderate mass needs precision gate
                      (prec.intent >= constants::RESOLVE_INTENT_PREC_MIN));
    
    // Entity: can be clarified during action if intent is strong
    float entity_mass = pool_.belief_mass("entity");
    bool entity_ok = (entity_mass >= constants::RESOLVE_ENTITY_ACTION) ||
                     (intent_ok && prec.entity < 0.35f);
    
    // Tone: optional
    float tone_mass = pool_.belief_mass("tone");
    bool tone_ok = (tone_mass >= constants::RESOLVE_TONE_ACTION) ||
                   (prec.tone < 0.30f);  // if tone precision is low, ignore it
    
    if (intent_ok && entity_ok) {
        d.can_act = true;
        if (!tone_ok) d.clarify_after.push_back("tone");
        // Note: entity_ok is true here, so the dead branch below is intentionally removed
    } else if (intent_ok && !entity_ok) {
        d.can_act = true;
        d.clarify_during.push_back("entity");
    } else {
        d.can_act = false;
        d.clarify_before.push_back("intent");
    }

    // Contested-dimension guard:
    // A contested dim only forces clarification if the WINNING belief is below
    // the action threshold.  If E1 says 0.90 and E2 says 0.30 the pool mass
    // is still 0.90 — we act on the strong stream and ignore the contest.
    // NOTE: intent threshold here is 0.75 (stricter than the 0.70 direct check)
    // because contested dims need a higher bar before we suppress clarification.
    for (const auto& dim : pool_.contested_dimensions()) {
        float mass = pool_.belief_mass(dim);
        std::cout << "[CONTEST] dim: " << dim << " mass: " << mass << "\n";
        float threshold = 0.0f;
        if (dim.compare("intent") == 0)       threshold = TurnCoordinator::CONTESTED_INTENT_THRESHOLD;
        else if (dim.compare("entity") == 0)  threshold = TurnCoordinator::CONTESTED_ENTITY_THRESHOLD;
        else if (dim.compare("tone") == 0)    threshold = TurnCoordinator::CONTESTED_TONE_THRESHOLD;
        else continue;  // unknown dim — skip

        std::cout << "[CONTEST] dim: " << dim
                  << " mass: " << mass
                  << " threshold: " << threshold
                  << " pass: " << (mass >= threshold ? "YES" : "NO") << "\n";

        if (mass < threshold) {
            // Entity contest should NOT block action if intent is strong.
            // Instead, add as clarify_during so Yuki can ask while acting.
            if (dim.compare("entity") == 0 && d.can_act) {
                bool already = false;
                for (const auto& cd : d.clarify_during)
                    if (cd.compare(dim) == 0) { already = true; break; }
                if (!already) d.clarify_during.push_back(dim);
            } else {
                bool already_listed = false;
                for (const auto& cb : d.clarify_before)
                    if (cb.compare(dim) == 0) { already_listed = true; break; }
                if (!already_listed) {
                    d.clarify_before.push_back(dim);
                    d.can_act = false;
                }
            }
        }
        // If mass >= threshold: strong stream wins — do nothing, proceed to act
    }

    // NOTE: force_clarify_next_turn is consumed in initialize_turn(), NOT here.
    // By the time resolve() runs, the flag has already been cleared.

    // After contested check, before generic fallback:
    if (!d.can_act && d.clarify_before.size() == 1 && d.clarify_before[0].compare("intent") == 0) {
        if (current_raw_input_.find("python") != std::string::npos) {
            d.template_family = "language_clarify";
            d.template_slot   = "python";
        } else if (current_raw_input_.find("java") != std::string::npos) {
            d.template_family = "language_clarify";
            d.template_slot   = "java";
        }
    }

    return d;
}

// ── queue_tools ──────────────────────────────────────────────────────────────

void TurnCoordinator::queue_tools(const ResolutionDecision& decision) {
    (void)decision; // no-op: tool dispatch is external concern
}

// ── shape_response ───────────────────────────────────────────────────────────

TurnResult TurnCoordinator::shape_response(const ResolutionDecision& decision) const {
    std::cout << "[SHAPE] veto: " << decision.veto
              << " can_act: " << decision.can_act
              << " clarify_before: " << decision.clarify_before.size()
              << " clarify_during: " << decision.clarify_during.size() << "\n";

    TurnResult r;
    r.turn_committed = true;
    r.can_act        = decision.can_act;
    r.veto           = decision.veto;  // always propagated

    if (use_variational_inference_ && vse_) {
        const auto& belief = vse_->currentBelief();
        const auto& policy_result = vse_->lastPolicy();
        const auto& map = belief.getMAP();

        // Only override if VSE has converged (MAP probability > 0.6)
        if (map.probability > 0.6f) {
            r.intent = map.intent;
            r.confidence = map.probability;
            r.engagement = static_cast<uint8_t>(map.engagement);
            r.urgency = static_cast<uint8_t>(map.urgency);
            r.policy_params = policy_result.selected_policy.parameters;
            r.free_energy = policy_result.final_G;
            r.execution_plan = policy_result.execution_plan;
        }
        // If VSE hasn't converged, fall back to BeliefPool values (already set above)
    }

    // ── 1. Safety veto: stop immediately ─────────────────────────────────────
    if (decision.veto) {
        r.requires_clarification = true;  // veto requires user acknowledgement
        r.template_family = "safety_check";
        r.template_slot   = "confirm";
        r.response_tone   = "urgent";
        return r;
    }

    // ── 2. Clarification required ─────────────────────────────────────────────
    if (!decision.can_act) {
        r.requires_clarification = true;
        if (!decision.template_family.empty()) {
            r.template_family = decision.template_family;
            r.template_slot   = decision.template_slot;
            r.response_tone   = "neutral";
            return r;
        }
        if (!decision.clarify_before.empty()) {
            const std::string& dim = decision.clarify_before[0];
            if (dim.compare("surprise_budget") == 0) {
                r.template_family = "fallback";
                r.template_slot   = "surprise";
            } else if (dim.compare("intent") == 0) {
                // FIX 5: Generate targeted clarification from raw input when possible
                std::string raw = state_.last_raw_input;
                std::string low; low.reserve(raw.size());
                for (unsigned char c : raw) low += static_cast<char>(std::tolower(c));

                if (low.find("python") != std::string::npos) {
                    r.template_family = "language_clarify";
                    r.template_slot   = "python_detail";
                } else if (low.find("java") != std::string::npos) {
                    r.template_family = "language_clarify";
                    r.template_slot   = "java_detail";
                } else if (low.find("language") != std::string::npos) {
                    r.template_family = "language_clarify";
                    r.template_slot   = "general_detail";
                } else {
                    r.template_family = "fallback";
                    r.template_slot   = "clarity";
                }
            } else {
                r.template_family = "dimension_clarify";
                r.template_slot   = dim;
            }
        } else {
            r.template_family = "fallback";
            r.template_slot   = "clarity";
        }
        r.response_tone = "neutral";
        return r;
    }

    // ── 3. Partial action: act on intent, clarify entity during ──────────────
    if (!decision.clarify_during.empty()) {
        // clarify_during does NOT block — Yuki responds AND refines
        r.requires_clarification = true;
        const std::string& edim  = decision.clarify_during[0];
        if (edim.compare("entity") == 0) {
            r.template_family = "dimension_clarify";
            r.template_slot   = "entity";
        } else {
            r.template_family = "dimension_clarify";
            r.template_slot   = edim;
        }
    }

    // ── 4. Full action path ───────────────────────────────────────────────────
    ResponseShaper::ToneProfile tp = ResponseShaper::profile_from_belief(pool_);

    // Build response from retrieved knowledge context
    std::string low_raw; low_raw.reserve(current_raw_input_.size());
    for (unsigned char c : current_raw_input_) low_raw += static_cast<char>(std::tolower(c));
    while (!low_raw.empty() && std::isspace(static_cast<unsigned char>(low_raw.back()))) low_raw.pop_back();
    while (!low_raw.empty() && std::isspace(static_cast<unsigned char>(low_raw.front()))) low_raw.erase(low_raw.begin());

    std::string base;
    if (!retrieved_context_.empty()) {
        // Extract the most relevant piece of context.
        // retrieved_context_ contains pipe-separated knowledge snippets.
        // Pick the best-matching snippet based on input keywords.
        std::string best_snippet = retrieved_context_;

        // If there are multiple snippets (separated by |), find the most relevant
        size_t pipe_pos = retrieved_context_.find('|');
        if (pipe_pos != std::string::npos) {
            // Split and score each snippet against the input
            std::vector<std::string> snippets;
            std::string remaining = retrieved_context_;
            while ((pipe_pos = remaining.find('|')) != std::string::npos) {
                std::string s = remaining.substr(0, pipe_pos);
                // Trim whitespace and source tags like [mass_curriculum]
                size_t bracket_end = s.find(']');
                if (bracket_end != std::string::npos)
                    s = s.substr(bracket_end + 1);
                while (!s.empty() && std::isspace(static_cast<unsigned char>(s.front()))) s.erase(s.begin());
                while (!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) s.pop_back();
                if (!s.empty()) snippets.push_back(s);
                remaining = remaining.substr(pipe_pos + 1);
            }
            // Last snippet
            {
                std::string s = remaining;
                size_t bracket_end = s.find(']');
                if (bracket_end != std::string::npos)
                    s = s.substr(bracket_end + 1);
                while (!s.empty() && std::isspace(static_cast<unsigned char>(s.front()))) s.erase(s.begin());
                while (!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) s.pop_back();
                if (!s.empty()) snippets.push_back(s);
            }

            // Score each snippet: count input words found in snippet
            int best_score = -1;
            for (const auto& snippet : snippets) {
                std::string low_snippet; low_snippet.reserve(snippet.size());
                for (unsigned char c : snippet) low_snippet += static_cast<char>(std::tolower(c));

                int score = 0;
                std::istringstream iss(low_raw);
                std::string word;
                while (iss >> word) {
                    // Skip common stop words
                    if (word.size() <= 2) continue;
                    if (word == std::string("the") || word == std::string("about") || word == std::string("tell") ||
                        word == std::string("what") || word == std::string("how") || word == std::string("why") ||
                        word == std::string("can") || word == std::string("you") || word == std::string("me")) continue;
                    if (low_snippet.find(word) != std::string::npos)
                        score += 1;
                }
                if (score > best_score) {
                    best_score = score;
                    best_snippet = snippet;
                }
            }
        } else {
            // Single snippet — strip source tag
            size_t bracket_end = best_snippet.find(']');
            if (bracket_end != std::string::npos)
                best_snippet = best_snippet.substr(bracket_end + 1);
            while (!best_snippet.empty() && std::isspace(static_cast<unsigned char>(best_snippet.front())))
                best_snippet.erase(best_snippet.begin());
        }

        base = best_snippet;
    } else {
        // No context retrieved — check KnowledgeDaemon for a direct answer
        if (knowledge_daemon_) {
            auto answer = knowledge_daemon_->query(current_raw_input_, 300);
            if (!answer.text.empty()) {
                base = answer.text;
            } else {
                if (r.template_family.empty()) {
                    r.template_family = "fallback";
                    r.template_slot   = "unknown_topic";
                }
                base = "";
            }
        } else {
            if (r.template_family.empty()) {
                r.template_family = "fallback";
                r.template_slot   = "unknown_topic";
            }
            base = "";
        }
    }

    r.response_text = ResponseShaper::apply(base, tp, state_.precision);
    r.response_tone = tp.acknowledge_first ? "empathetic" : "neutral";
    return r;
}

// ── end_turn ─────────────────────────────────────────────────────────────────

void TurnCoordinator::end_turn(const ResolutionDecision& decision) {
    // Apply precision scratch → state (atomically per turn)
    if (precision_dirty_) {
        state_.precision = precision_scratch_;
        precision_dirty_ = false;
    }
    state_.precision.recover();

    // [D5] Reset force_clarify flag; re-set if this turn's surprise ≥ MAX
    state_.force_clarify_next_turn = false;

    // [D4] Check BEFORE decay (rule 9 is explicit on this ordering)
    if (state_.accumulated_surprise >= constants::SURPRISE_MAX)
        state_.force_clarify_next_turn = true;

    // Decay: keep (SURPRISE_DECAY + SURPRISE_CARRY) = 0.70 of accumulated [D4]
    state_.accumulated_surprise *=
        (constants::SURPRISE_DECAY + constants::SURPRISE_CARRY);

    // Contradiction lifecycle
    process_contradictions();

    // Meta-cognitive update
    float intent_conf = pool_.belief_mass("intent");
    meta_update(decision.can_act, intent_conf);

    // Publish turn completion to GlobalWorkspace / CoreBus
    // CMF, NeuralSpine, and SelfModel subscribe to ACTION_COMPLETED
    yuki::gw::Message gc_msg;
    gc_msg.topic         = yuki::gw::Topic::ACTION_COMPLETED;
    gc_msg.source_module = "TurnCoordinator";
    gc_msg.salience      = 0.5f;
    gc_msg.payload_json  = "{\"can_act\":" + std::string(decision.can_act ? "true" : "false") +
                           ",\"intent_conf\":" + std::to_string(intent_conf) + "}";
    yuki::gw::CoreBus::instance().publish(gc_msg);
    yuki::infra::ModuleRegistry::instance().heartbeat("TurnCoordinator");
}

void TurnCoordinator::process_contradictions() {
    for (auto& c : state_.active_contradictions)
        c.tick();

    state_.active_contradictions.erase(
        std::remove_if(state_.active_contradictions.begin(),
                       state_.active_contradictions.end(),
                       [](const ContradictionEvent& c){ return c.should_archive(); }),
        state_.active_contradictions.end());

    for (auto& c : state_.active_contradictions)
        if (c.should_surface() && !c.surfaced_to_user)
            c.surfaced_to_user = true;
}

void TurnCoordinator::meta_update(bool action_was_correct, float predicted_confidence) {
    meta_.update(action_was_correct, predicted_confidence);
    if (meta_.should_enter_anti_hesitation())
        meta_.anti_hesitation_mode = true;
}

void TurnCoordinator::distill_memory() {
    if (memory_store_) {
        memory_store_->distill({});
    }
}

} // namespace yuki
