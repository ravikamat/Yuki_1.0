// TinyMLP.h — Yuki_1.0 DMC neural backbone (48→128→24, ~9.4K params)
// Pure C++17. No external ML libraries.
#pragma once
#include <vector>
#include <cstddef>

namespace yuki {
namespace memory {

class TinyMLP {
public:
    // Architecture constants
    static constexpr size_t INPUT_DIM  = 48;
    static constexpr size_t HIDDEN_DIM = 128;
    static constexpr size_t OUTPUT_DIM = 24;

    // Flat weight layout: W1[H×I] | b1[H] | W2[O×H] | b2[O]
    static constexpr size_t W1_OFF = 0;
    static constexpr size_t b1_OFF = W1_OFF + HIDDEN_DIM * INPUT_DIM;  // 6144
    static constexpr size_t W2_OFF = b1_OFF + HIDDEN_DIM;               // 6272
    static constexpr size_t b2_OFF = W2_OFF + OUTPUT_DIM * HIDDEN_DIM;  // 9344
    static constexpr size_t TOTAL  = b2_OFF + OUTPUT_DIM;               // 9368

    // Xavier/He init on construction
    TinyMLP();

    // Forward pass. input.size() must equal INPUT_DIM. output.size() == OUTPUT_DIM.
    // Hidden: ReLU.  Output: Sigmoid → values strictly in (0,1).
    std::vector<float> forward(const std::vector<float>& input) const;

    // Serialization (for T3 blob storage / reload)
    const std::vector<float>& getWeights() const { return w_; }
    void                      setWeights(const std::vector<float>& w);
    size_t                    paramCount() const { return TOTAL; }

private:
    std::vector<float> w_;   // all weights + biases, size == TOTAL

    void  xavierInit();
    static float relu(float x) { return x > 0.0f ? x : 0.0f; }
    static float sigmoid(float x);
};

} // namespace memory
} // namespace yuki
