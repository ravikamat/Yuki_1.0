// DifferentialMemoryController.cpp — Yuki_1.0 DMC implementation
#include "brain/memory/DifferentialMemoryController.h"
#include <algorithm>
#include <cmath>

namespace yuki {
namespace memory {

DifferentialMemoryController::DifferentialMemoryController() = default;

// ── Input assembly ────────────────────────────────────────────────────────────
// Layout: [0..23] vseState, [24..31] obsStats, [32..47] memCtx
std::vector<float> DifferentialMemoryController::assembleInput(
    const std::vector<float>& vseState,
    const std::vector<float>& obsStats,
    const std::vector<float>& memCtx) const
{
    std::vector<float> inp(TinyMLP::INPUT_DIM, 0.0f);
    // Partition 1: VSE state (24 dims, offset 0)
    size_t v = std::min(vseState.size(), size_t(24));
    std::copy(vseState.begin(), vseState.begin() + static_cast<ptrdiff_t>(v), inp.begin());
    // Partition 2: observation stats (8 dims, offset 24)
    size_t o = std::min(obsStats.size(), size_t(8));
    std::copy(obsStats.begin(), obsStats.begin() + static_cast<ptrdiff_t>(o), inp.begin() + 24);
    // Partition 3: memory context (16 dims, offset 32)
    size_t m = std::min(memCtx.size(), size_t(16));
    std::copy(memCtx.begin(), memCtx.begin() + static_cast<ptrdiff_t>(m), inp.begin() + 32);
    return inp;
}

// ── Per-episode memory context (16 dims) ──────────────────────────────────────
std::vector<float> DifferentialMemoryController::buildEpisodicCtx(
    const EpisodicStore::MemoryStats& s) const
{
    std::vector<float> ctx(16, 0.0f);
    ctx[0] = std::min(1.0f, static_cast<float>(s.accessCount)        / 100.0f);
    ctx[1] = std::min(1.0f, static_cast<float>(s.reinforcementCount) / 50.0f);
    ctx[2] = std::min(1.0f, static_cast<float>(s.ageHours)           / 168.0f); // 1 week
    ctx[3] = clamp01((s.lastFreeEnergy + 10.0f) / 20.0f);  // G ∈ [-10, 10] → [0, 1]
    // ctx[4..15] = 0.0f (spare, future use)
    return ctx;
}

// ── Per-concept memory context (16 dims) ──────────────────────────────────────
std::vector<float> DifferentialMemoryController::buildConceptCtx(
    const HdcSemanticGraph::ConceptStats& s) const
{
    std::vector<float> ctx(16, 0.0f);
    ctx[0] = std::min(1.0f, static_cast<float>(s.accessCount)        / 100.0f);
    ctx[1] = std::min(1.0f, static_cast<float>(s.reinforcementCount) / 50.0f);
    ctx[2] = std::min(1.0f, static_cast<float>(s.ageHours)           / 168.0f);
    ctx[3] = clamp01(s.heuristicStrength);
    return ctx;
}

// ── decideWrite ───────────────────────────────────────────────────────────────
// Runs MLP, maps output dims 16–23 → WriteStrategy
DifferentialMemoryController::WriteStrategy
DifferentialMemoryController::decideWrite(
    const std::vector<float>& vseState,
    const std::vector<float>& obsStats,
    const std::vector<float>& memCtx)
{
    auto inp = assembleInput(vseState, obsStats, memCtx);
    auto out = mlp_.forward(inp);   // out.size() == 24, all in (0,1)

    WriteStrategy ws;
    ws.write_strength         = clamp01(out[16]);
    ws.lsh_table_weights[0]   = clamp01(out[17]);
    ws.lsh_table_weights[1]   = clamp01(out[18]);
    ws.lsh_table_weights[2]   = clamp01(out[19]);
    ws.lsh_table_weights[3]   = clamp01(out[20]);
    ws.hard_location_sparsity = clamp01(out[21]);
    ws.reserved               = clamp01(out[22]);
    return ws;
}

// ── evaluatePromotions ────────────────────────────────────────────────────────
// Runs MLP once per candidate; maps dims 0–7 → T1→T2 score, 8–15 → T2→T3 score
std::vector<DifferentialMemoryController::PromotionDecision>
DifferentialMemoryController::evaluatePromotions(
    const std::vector<EpisodicStore::MemoryStats>&    episodicStats,
    const std::vector<HdcSemanticGraph::ConceptStats>& semanticStats)
{
    std::vector<PromotionDecision> decisions;
    decisions.reserve(episodicStats.size() + semanticStats.size());

    const std::vector<float> zero24(24, 0.0f);
    const std::vector<float> zero8 (8,  0.0f);

    // ── Episodic candidates (T1 → T2) ────────────────────────────────────────
    for (const auto& s : episodicStats) {
        auto ctx = buildEpisodicCtx(s);
        auto inp = assembleInput(zero24, zero8, ctx);
        auto out = mlp_.forward(inp);

        PromotionDecision d;
        d.memoryId   = s.id;
        d.isEpisodic = true;
        // Average of dims 0–7 → T1→T2 score
        float sum = 0.0f;
        for (int i = 0; i < 8; ++i) sum += clamp01(out[static_cast<size_t>(i)]);
        d.t1_to_t2_score = sum / 8.0f;
        // Average of dims 8–15 → T2→T3 score
        sum = 0.0f;
        for (int i = 8; i < 16; ++i) sum += clamp01(out[static_cast<size_t>(i)]);
        d.t2_to_t3_score = sum / 8.0f;
        decisions.push_back(std::move(d));
    }

    // ── Semantic candidates (T2 → T3) ────────────────────────────────────────
    for (const auto& s : semanticStats) {
        auto ctx = buildConceptCtx(s);
        auto inp = assembleInput(zero24, zero8, ctx);
        auto out = mlp_.forward(inp);

        PromotionDecision d;
        d.memoryId   = s.id;
        d.isEpisodic = false;
        float sum = 0.0f;
        for (int i = 0; i < 8; ++i) sum += clamp01(out[static_cast<size_t>(i)]);
        d.t1_to_t2_score = sum / 8.0f;
        sum = 0.0f;
        for (int i = 8; i < 16; ++i) sum += clamp01(out[static_cast<size_t>(i)]);
        d.t2_to_t3_score = sum / 8.0f;
        decisions.push_back(std::move(d));
    }

    return decisions;
}

} // namespace memory
} // namespace yuki
