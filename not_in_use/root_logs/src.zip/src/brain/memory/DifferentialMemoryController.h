// DifferentialMemoryController.h — Yuki_1.0 DMC
// MLP-guided decisions: SDM write strategy + T1→T2→T3 promotion scoring.
// Owns one TinyMLP (48→128→24). Thread-safe for read-only dream epoch calls.
#pragma once
#include "brain/memory/TinyMLP.h"
#include "brain/memory/EpisodicStore.h"
#include "brain/memory/HdcSemanticGraph.h"
#include <vector>
#include <string>
#include <algorithm>

namespace yuki {
namespace memory {

class DifferentialMemoryController {
public:
    // ── Output structs ────────────────────────────────────────────────────────

    // WriteStrategy: how to bias the next SDM write (from dims 16–23 of MLP output)
    struct WriteStrategy {
        float write_strength         = 0.5f;
        float lsh_table_weights[4]   = {0.25f, 0.25f, 0.25f, 0.25f};
        float hard_location_sparsity = 0.5f;
        float reserved               = 0.5f;  // dim 23 — spare
    };

    // PromotionDecision: per-candidate MLP score (from dims 0–15 of MLP output)
    struct PromotionDecision {
        std::string memoryId;          // episode_id (T1) or concept name (T2)
        bool        isEpisodic = true; // true = T1 candidate, false = T2 candidate
        float       t1_to_t2_score = 0.0f;
        float       t2_to_t3_score = 0.0f;
    };

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    DifferentialMemoryController();

    // ── Main interface ────────────────────────────────────────────────────────

    // Decide SDM write biasing from current cognitive state.
    // vseState: 24 floats (q_intent[8] + q_engagement[3] + q_urgency[2] + meta[11])
    // obsStats:  8 floats (cross_modal_agreement, mean_deviation, snr, dropout_rate, + 4)
    // memCtx:   16 floats (access_count, reinforcement_count, age_hours, FE_delta, + 12)
    WriteStrategy decideWrite(const std::vector<float>& vseState,
                              const std::vector<float>& obsStats,
                              const std::vector<float>& memCtx);

    // Score every episode and concept candidate for promotion.
    // Runs MLP once per candidate; all scores clamped to [0,1].
    std::vector<PromotionDecision> evaluatePromotions(
        const std::vector<EpisodicStore::MemoryStats>&   episodicStats,
        const std::vector<HdcSemanticGraph::ConceptStats>& semanticStats);

    // Serialization — expose MLP weights for T3 blob storage
    const std::vector<float>& getMlpWeights() const { return mlp_.getWeights(); }
    void setMlpWeights(const std::vector<float>& w)  { mlp_.setWeights(w); }

private:
    TinyMLP mlp_;

    // Assemble the full 48-dim input from the three 24+8+16 partitions
    std::vector<float> assembleInput(const std::vector<float>& vseState,
                                     const std::vector<float>& obsStats,
                                     const std::vector<float>& memCtx) const;

    // Build a 16-dim memory-context vector from episode / concept stats
    std::vector<float> buildEpisodicCtx(const EpisodicStore::MemoryStats& s) const;
    std::vector<float> buildConceptCtx(const HdcSemanticGraph::ConceptStats& s) const;

    static float clamp01(float x) {
        return x < 0.0f ? 0.0f : (x > 1.0f ? 1.0f : x);
    }
};

} // namespace memory
} // namespace yuki
