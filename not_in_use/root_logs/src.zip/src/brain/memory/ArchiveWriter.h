// ArchiveWriter.h — Yuki_1.0 T4: streaming .yuk archive writer
#pragma once
#include "brain/memory/ColumnarArchiveFormat.h"
#include <fstream>
#include <memory>
#include <string>
#include <vector>

namespace yuki {
namespace memory {

class ArchiveWriter {
public:
    explicit ArchiveWriter(const std::string& directory);
    ~ArchiveWriter();

    // Open a new archive file in directory_/name.yuk, write file header.
    bool beginArchive(const std::string&                    name,
                      const std::vector<ColumnarArchiveFormat::ColumnSchema>& schema);

    // Serialise one row group and append to open archive.
    bool writeRowGroup(const std::vector<ColumnarArchiveFormat::ColumnData>& columns);

    // Write footer (Merkle root), close file. Returns Merkle root hex in out_merkle_root.
    bool finalizeArchive(std::string& out_merkle_root);

    // Standalone: open an existing file and verify its Merkle root.
    static bool verifyArchive(const std::string& filepath);

private:
    std::string  directory_;
    std::string  current_file_;
    std::unique_ptr<std::ofstream> stream_;
    std::vector<uint64_t>          row_group_offsets_;
    std::vector<std::string>       chunk_hashes_;    // one per column per row group
    uint64_t                       header_end_pos_ = 0;
};

} // namespace memory
} // namespace yuki
