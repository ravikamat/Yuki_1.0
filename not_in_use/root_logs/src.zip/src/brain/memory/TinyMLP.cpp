// TinyMLP.cpp — Yuki_1.0 DMC neural backbone implementation
#include "brain/memory/TinyMLP.h"
#include <cmath>
#include <cstdlib>
#include <stdexcept>
#include <algorithm>

namespace yuki {
namespace memory {

TinyMLP::TinyMLP() : w_(TOTAL, 0.0f) {
    xavierInit();
}

void TinyMLP::xavierInit() {
    // He-init variant: weight = uniform(-scale, +scale), scale = sqrt(2 / fan_in)
    // Biases remain zero.
    // W1: fan_in = INPUT_DIM
    float scale1 = std::sqrt(2.0f / static_cast<float>(INPUT_DIM));
    for (size_t i = W1_OFF; i < b1_OFF; ++i) {
        float r = (static_cast<float>(rand()) / static_cast<float>(RAND_MAX)) * 2.0f - 1.0f;
        w_[i] = r * scale1;
    }
    // b1 stays zero (already zero from vector init)

    // W2: fan_in = HIDDEN_DIM
    float scale2 = std::sqrt(2.0f / static_cast<float>(HIDDEN_DIM));
    for (size_t i = W2_OFF; i < b2_OFF; ++i) {
        float r = (static_cast<float>(rand()) / static_cast<float>(RAND_MAX)) * 2.0f - 1.0f;
        w_[i] = r * scale2;
    }
    // b2 stays zero
}

void TinyMLP::setWeights(const std::vector<float>& w) {
    if (w.size() != TOTAL)
        throw std::invalid_argument("TinyMLP::setWeights: wrong weight count");
    w_ = w;
}

float TinyMLP::sigmoid(float x) {
    // Numerically stable sigmoid
    if (x >= 0.0f) return 1.0f / (1.0f + std::exp(-x));
    float ex = std::exp(x);
    return ex / (1.0f + ex);
}

std::vector<float> TinyMLP::forward(const std::vector<float>& input) const {
    if (input.size() != INPUT_DIM)
        throw std::invalid_argument("TinyMLP::forward: input dim mismatch");

    // ── Layer 1: hidden = ReLU(W1 * input + b1) ──────────────────────────────
    const float* W1 = w_.data() + W1_OFF;
    const float* b1 = w_.data() + b1_OFF;
    std::vector<float> hidden(HIDDEN_DIM);
    for (size_t h = 0; h < HIDDEN_DIM; ++h) {
        float sum = b1[h];
        const float* row = W1 + h * INPUT_DIM;
        for (size_t i = 0; i < INPUT_DIM; ++i) {
            sum += row[i] * input[i];
        }
        hidden[h] = relu(sum);
    }

    // ── Layer 2: output = Sigmoid(W2 * hidden + b2) ──────────────────────────
    const float* W2 = w_.data() + W2_OFF;
    const float* b2 = w_.data() + b2_OFF;
    std::vector<float> output(OUTPUT_DIM);
    for (size_t o = 0; o < OUTPUT_DIM; ++o) {
        float sum = b2[o];
        const float* row = W2 + o * HIDDEN_DIM;
        for (size_t h = 0; h < HIDDEN_DIM; ++h) {
            sum += row[h] * hidden[h];
        }
        output[o] = sigmoid(sum);
    }

    return output;
}

} // namespace memory
} // namespace yuki
