// ProceduralStore.cpp — Yuki_1.0 T3 Procedural Memory implementation
#include "brain/memory/ProceduralStore.h"
#include <sqlite3.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <iostream>
#include <chrono>
#include <algorithm>

namespace fs = std::filesystem;

namespace yuki {
namespace memory {

ProceduralStore::ProceduralStore(std::string db_path, std::string blob_dir)
    : db_path_(std::move(db_path)), blob_dir_(std::move(blob_dir)) {}

bool ProceduralStore::init() {
    if (!ensureBlobDir()) return false;
    if (!ensureSchema())  return false;
    std::cout << "[ProceduralStore] T3 initialized. DB=" << db_path_
              << " blobs=" << blob_dir_ << "\n";
    return true;
}

bool ProceduralStore::ensureBlobDir() {
    try {
        fs::create_directories(blob_dir_);
        return true;
    } catch (const std::exception& e) {
        std::cerr << "[ProceduralStore] Cannot create blob dir " << blob_dir_
                  << ": " << e.what() << "\n";
        return false;
    }
}

bool ProceduralStore::ensureSchema() {
    sqlite3* db = nullptr;
    if (sqlite3_open(db_path_.c_str(), &db) != SQLITE_OK) {
        std::cerr << "[ProceduralStore] Cannot open DB: " << db_path_ << "\n";
        return false;
    }
    const char* sql = R"(
        CREATE TABLE IF NOT EXISTS skills (
            id                 INTEGER PRIMARY KEY AUTOINCREMENT,
            name               TEXT    NOT NULL,
            content_hash       TEXT    NOT NULL UNIQUE,
            access_count       INTEGER NOT NULL DEFAULT 0,
            reinforcement_count INTEGER NOT NULL DEFAULT 0,
            created_at_ms      INTEGER NOT NULL DEFAULT 0,
            embedding_csv      TEXT    NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_skills_name ON skills(name);
    )";
    char* err = nullptr;
    bool ok = (sqlite3_exec(db, sql, nullptr, nullptr, &err) == SQLITE_OK);
    if (err) sqlite3_free(err);
    sqlite3_close(db);
    return ok;
}

bool ProceduralStore::writeBlobFile(const std::string& hash,
                                     const std::vector<uint8_t>& data) {
    std::string path = blob_dir_ + hash + ".blob";
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    f.write(reinterpret_cast<const char*>(data.data()),
            static_cast<std::streamsize>(data.size()));
    return f.good();
}

std::string ProceduralStore::embeddingToCSV(const std::vector<float>& v) {
    std::ostringstream ss;
    for (size_t i = 0; i < v.size(); ++i) {
        if (i > 0) ss << ',';
        ss << v[i];
    }
    return ss.str();
}

std::vector<float> ProceduralStore::csvToEmbedding(const std::string& csv) {
    std::vector<float> out;
    if (csv.empty()) return out;
    std::istringstream ss(csv);
    std::string tok;
    while (std::getline(ss, tok, ',')) {
        try { out.push_back(std::stof(tok)); }
        catch (...) { out.push_back(0.0f); }
    }
    return out;
}

float ProceduralStore::dotProduct(const std::vector<float>& a,
                                   const std::vector<float>& b) {
    float sum = 0.0f;
    size_t n = std::min(a.size(), b.size());
    for (size_t i = 0; i < n; ++i) sum += a[i] * b[i];
    return sum;
}

bool ProceduralStore::storeSkill(const std::string&         name,
                                  const std::vector<uint8_t>& bytecode,
                                  const std::vector<float>&   embedding) {
    // Content hash via MerkleDAG::hashString() — reuses existing SHA-256
    std::string content(bytecode.begin(), bytecode.end());
    std::string hash = dag_.hashString(content);

    if (!writeBlobFile(hash, bytecode)) {
        std::cerr << "[ProceduralStore] Blob write failed for '" << name << "'\n";
        return false;
    }

    uint64_t now_ms = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());

    sqlite3* db = nullptr;
    if (sqlite3_open(db_path_.c_str(), &db) != SQLITE_OK) return false;

    const char* sql =
        "INSERT OR IGNORE INTO skills "
        "(name, content_hash, created_at_ms, embedding_csv) VALUES (?,?,?,?)";
    sqlite3_stmt* stmt = nullptr;
    bool ok = false;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        std::string emb_csv = embeddingToCSV(embedding);
        sqlite3_bind_text (stmt, 1, name.c_str(),    -1, SQLITE_TRANSIENT);
        sqlite3_bind_text (stmt, 2, hash.c_str(),    -1, SQLITE_TRANSIENT);
        sqlite3_bind_int64(stmt, 3, static_cast<int64_t>(now_ms));
        sqlite3_bind_text (stmt, 4, emb_csv.c_str(), -1, SQLITE_TRANSIENT);
        ok = (sqlite3_step(stmt) == SQLITE_DONE);
        sqlite3_finalize(stmt);
    }
    sqlite3_close(db);
    return ok;
}

std::optional<ProceduralStore::SkillBlob>
ProceduralStore::retrieveSkill(const std::vector<float>& queryEmbedding) const {
    auto skills = listSkills();
    if (skills.empty()) return std::nullopt;

    float best = -1e9f;
    size_t best_i = 0;
    for (size_t i = 0; i < skills.size(); ++i) {
        float score = dotProduct(queryEmbedding, skills[i].embedding);
        if (score > best) { best = score; best_i = i; }
    }
    // Increment access_count (best-effort — ignore failure)
    sqlite3* db = nullptr;
    if (sqlite3_open(db_path_.c_str(), &db) == SQLITE_OK) {
        sqlite3_stmt* stmt = nullptr;
        if (sqlite3_prepare_v2(db,
                "UPDATE skills SET access_count=access_count+1 WHERE id=?",
                -1, &stmt, nullptr) == SQLITE_OK) {
            sqlite3_bind_int64(stmt, 1, skills[best_i].id);
            sqlite3_step(stmt);
            sqlite3_finalize(stmt);
        }
        sqlite3_close(db);
    }
    return skills[best_i];
}

std::vector<ProceduralStore::SkillBlob> ProceduralStore::listSkills() const {
    std::vector<SkillBlob> out;
    sqlite3* db = nullptr;
    if (sqlite3_open(db_path_.c_str(), &db) != SQLITE_OK) return out;

    const char* sql =
        "SELECT id, name, content_hash, access_count, reinforcement_count, "
        "created_at_ms, embedding_csv FROM skills ORDER BY id";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            SkillBlob b;
            b.id  = sqlite3_column_int64(stmt, 0);
            auto col_txt = [&](int c) -> std::string {
                const char* p = reinterpret_cast<const char*>(sqlite3_column_text(stmt, c));
                return p ? p : "";
            };
            b.name              = col_txt(1);
            b.content_hash      = col_txt(2);
            b.access_count       = static_cast<size_t>(sqlite3_column_int(stmt, 3));
            b.reinforcement_count = static_cast<size_t>(sqlite3_column_int(stmt, 4));
            b.created_at_ms      = static_cast<uint64_t>(sqlite3_column_int64(stmt, 5));
            b.embedding          = csvToEmbedding(col_txt(6));
            out.push_back(std::move(b));
        }
        sqlite3_finalize(stmt);
    }
    sqlite3_close(db);
    return out;
}

bool ProceduralStore::reinforceSkill(int64_t id) {
    sqlite3* db = nullptr;
    if (sqlite3_open(db_path_.c_str(), &db) != SQLITE_OK) return false;
    const char* sql =
        "UPDATE skills "
        "SET reinforcement_count=reinforcement_count+1, "
        "    access_count=access_count+1 "
        "WHERE id=?";
    sqlite3_stmt* stmt = nullptr;
    bool ok = false;
    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_int64(stmt, 1, id);
        ok = (sqlite3_step(stmt) == SQLITE_DONE);
        sqlite3_finalize(stmt);
    }
    sqlite3_close(db);
    return ok;
}

} // namespace memory
} // namespace yuki
