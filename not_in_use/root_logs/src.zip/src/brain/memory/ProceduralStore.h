// ProceduralStore.h — Yuki_1.0 T3 Procedural Memory
// Frozen binary blob storage for compiled skills.
// SQLite metadata + flat files under data/procedural/{sha256}.blob
// SHA-256 via MerkleDAG::hashString() — no second implementation.
#pragma once
#include "brain/memory/MerkleDAG.h"
#include <string>
#include <vector>
#include <optional>
#include <cstdint>

struct sqlite3;

namespace yuki {
namespace memory {

class ProceduralStore {
public:
    // ── Skill record ──────────────────────────────────────────────────────────
    struct SkillBlob {
        int64_t     id                  = -1;
        std::string name;
        std::string content_hash;        // SHA-256 hex
        std::vector<float> embedding;    // 64-dim float (for dot-product retrieval)
        size_t      access_count        = 0;
        size_t      reinforcement_count = 0;
        uint64_t    created_at_ms       = 0;
    };

    explicit ProceduralStore(std::string db_path  = "data/brain/procedural.db",
                             std::string blob_dir = "data/procedural/");
    ~ProceduralStore() = default;

    bool init();

    // Write blob file + SQLite row. Returns false on hash collision (already stored).
    bool storeSkill(const std::string&         name,
                    const std::vector<uint8_t>& bytecode,
                    const std::vector<float>&   embedding);

    // Nearest-neighbour retrieval by dot-product (linear scan).
    std::optional<SkillBlob> retrieveSkill(const std::vector<float>& queryEmbedding) const;

    // List all stored skills ordered by id.
    std::vector<SkillBlob> listSkills() const;

    // Increment reinforcement_count + access_count for skill id.
    bool reinforceSkill(int64_t id);

private:
    std::string  db_path_;
    std::string  blob_dir_;
    mutable MerkleDAG dag_;   // mutable: hashString() may be non-const on some builds

    bool ensureSchema();
    bool ensureBlobDir();
    bool writeBlobFile(const std::string& hash, const std::vector<uint8_t>& data);

    static float        dotProduct(const std::vector<float>& a, const std::vector<float>& b);
    static std::string  embeddingToCSV(const std::vector<float>& v);
    static std::vector<float> csvToEmbedding(const std::string& csv);
};

} // namespace memory
} // namespace yuki
