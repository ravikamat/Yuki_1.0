// ArchiveWriter.cpp — T4 streaming archive writer implementation
#include "brain/memory/ArchiveWriter.h"
#include <filesystem>
#include <iostream>

namespace fs = std::filesystem;

namespace yuki {
namespace memory {

ArchiveWriter::ArchiveWriter(const std::string& directory)
    : directory_(directory) {}

ArchiveWriter::~ArchiveWriter() {
    if (stream_ && stream_->is_open()) {
        std::string dummy;
        finalizeArchive(dummy);
    }
}

bool ArchiveWriter::beginArchive(
        const std::string& name,
        const std::vector<ColumnarArchiveFormat::ColumnSchema>& schema) {
    // Ensure directory exists
    try { fs::create_directories(directory_); }
    catch (const std::exception& e) {
        std::cerr << "[ArchiveWriter] Cannot create directory " << directory_
                  << ": " << e.what() << "\n";
        return false;
    }

    current_file_ = directory_ + "/" + name + ".yuk";
    stream_ = std::make_unique<std::ofstream>(current_file_, std::ios::binary | std::ios::trunc);
    if (!stream_->is_open()) {
        std::cerr << "[ArchiveWriter] Cannot open " << current_file_ << "\n";
        return false;
    }

    row_group_offsets_.clear();
    chunk_hashes_.clear();

    if (!ColumnarArchiveFormat::writeHeader(*stream_, schema)) return false;
    header_end_pos_ = static_cast<uint64_t>(stream_->tellp());
    return true;
}

bool ArchiveWriter::writeRowGroup(
        const std::vector<ColumnarArchiveFormat::ColumnData>& columns) {
    if (!stream_ || !stream_->is_open()) return false;

    uint64_t offset = static_cast<uint64_t>(stream_->tellp());
    row_group_offsets_.push_back(offset);

    return ColumnarArchiveFormat::writeRowGroup(*stream_, columns, chunk_hashes_);
}

bool ArchiveWriter::finalizeArchive(std::string& out_merkle_root) {
    if (!stream_ || !stream_->is_open()) return false;

    bool ok = ColumnarArchiveFormat::writeFooter(
        *stream_, row_group_offsets_, chunk_hashes_, out_merkle_root);

    stream_->flush();
    stream_->close();
    stream_.reset();

    if (ok) {
        std::cout << "[ArchiveWriter] Finalized " << current_file_
                  << " merkle_root=" << out_merkle_root.substr(0,16) << "...\n";
    }
    return ok;
}

bool ArchiveWriter::verifyArchive(const std::string& filepath) {
    return ColumnarArchiveFormat::verifyArchive(filepath);
}

} // namespace memory
} // namespace yuki
