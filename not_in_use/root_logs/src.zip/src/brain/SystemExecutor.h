#pragma once
#include "ExecutionTypes.h"
#include "ScriptRunner.h"
#include "FileOperator.h"
#include "UIAutomationController.h"

class SystemExecutor {
public:
    ExecutionResult run(const ExecutionPlan& plan);

private:
    StepResult executeApiStep(const ActionStep& step);

    ScriptRunner scriptRunner_;
    FileOperator fileOperator_;
    UIAutomationController uiAutomation_;
};
