#include "SystemExecutor.h"
#include <iostream>

ExecutionResult SystemExecutor::run(const ExecutionPlan& plan) {
    ExecutionResult result;

    if (plan.requiresApproval) {
        result.success = false;
        result.summary = "Execution blocked: plan requires approval.";
        return result;
    }

    for (const auto& step : plan.stepsExpanded) {
        StepResult sr;

        switch (step.backend) {
            case ActionBackend::API:
                sr = executeApiStep(step);
                break;
            case ActionBackend::CLI_SCRIPT:
                // Route to ScriptRunner or FileOperator depending on command
                if (step.commandOrApi == "create" || step.commandOrApi == "delete" || 
                    step.commandOrApi == "copy" || step.commandOrApi == "move" || 
                    step.commandOrApi == "rename") {
                    sr = fileOperator_.execute(step);
                } else {
                    sr = scriptRunner_.execute(step);
                }
                break;
            case ActionBackend::GUI_AUTOMATION:
                sr = uiAutomation_.execute(step);
                break;
            default:
                sr.stepId = step.id;
                sr.success = false;
                sr.summary = "Unknown ActionBackend";
                break;
        }

        result.steps.push_back(sr);

        if (!sr.success) {
            result.success = false;
            result.summary = "Execution failed at step: " + step.id + " - " + sr.summary;
            return result;
        }
    }

    result.success = true;
    result.summary = "Execution completed successfully.";
    return result;
}

StepResult SystemExecutor::executeApiStep(const ActionStep& step) {
    StepResult sr;
    sr.stepId = step.id;
    // API execution would usually route to an internal client.
    sr.success = true;
    sr.summary = "Simulated API execution for " + step.commandOrApi;
    return sr;
}
