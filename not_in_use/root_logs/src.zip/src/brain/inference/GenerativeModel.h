#pragma once
#include "BeliefState.h"
#include "input/encoding/SensoryObservation.h"
#include <vector>

namespace yuki::inference {
class GenerativeModel {
public:
    GenerativeModel();
    void bootstrapStructuralPriors();  // one-time: seed known linguistic patterns
    yuki::perception::FeatureVector likelihood(
        const BeliefState::MAPState& state,
        yuki::perception::Modality modality) const;
    std::vector<float> predictionError(
        const yuki::perception::SensoryObservation& obs,
        const BeliefState& belief) const;
    yuki::perception::PrecisionMatrix expectedPrecision(
        yuki::perception::Modality modality) const;
private:
    std::vector<float> intent_to_audio_features_[8];
    std::vector<float> intent_to_visual_features_[8];
    std::vector<float> intent_to_text_features_[8];
    void initializeMappings_();

public:
    // Learning: update generative model from observed (observation, intent) pairs
    // Called by VariationalStateEstimator after each turn when the true intent is known
    void updateMapping(yuki::IntentClass intent,
                       yuki::perception::Modality modality,
                       const std::vector<float>& observed_features,
                       float learning_rate = 0.05f);

    // Decay old mappings toward neutral to prevent overfitting
    void decayMappings_(float decay_factor = 0.999f);

    // Persistence: save/load learned mappings to/from SQLite
    bool saveMappings(const std::string& db_path = "data/generative_model.db");
    bool loadMappings(const std::string& db_path = "data/generative_model.db");

    // Get current mapping for inspection/debugging
    std::vector<float> getMapping(yuki::IntentClass intent,
                                   yuki::perception::Modality modality) const;
};
}
