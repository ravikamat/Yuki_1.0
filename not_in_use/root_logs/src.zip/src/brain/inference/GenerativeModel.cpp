#include "GenerativeModel.h"
#include "brain/predictive/predictive_turn_engine.h"
#include <cmath>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iostream>

namespace yuki::inference {
GenerativeModel::GenerativeModel() {
    initializeMappings_();
    bootstrapStructuralPriors();
}

yuki::perception::FeatureVector GenerativeModel::likelihood(
    const BeliefState::MAPState& state,
    yuki::perception::Modality modality) const
{
    yuki::perception::FeatureVector result;
    size_t intent_idx = static_cast<size_t>(state.intent);
    switch (modality) {
        case yuki::perception::Modality::AUDIO:
            result.values = intent_to_audio_features_[intent_idx];
            result.dimension_names = {"rms", "rms_ema", "spectral_proxy", "vad", "noise_floor", "dynamic_range", "has_pcm", "confidence"};
            break;
        case yuki::perception::Modality::VISUAL_CAMERA:
            result.values = intent_to_visual_features_[intent_idx];
            result.dimension_names = {"brightness", "motion", "motion_ema", "face_present", "face_density", "motion_binary", "lighting", "confidence", "bright_face", "motion_face"};
            break;
        case yuki::perception::Modality::TEXT:
            result.values = intent_to_text_features_[intent_idx];
            result.dimension_names = {"length_norm", "word_count_norm", "question", "command", "emotional", "technical", "greeting", "urgency", "yuki_name", "action_cue", "polarity", "confidence"};
            break;
        default:
            result.values = {0.5f};
            result.dimension_names = {"default"};
    }
    return result;
}

std::vector<float> GenerativeModel::predictionError(
    const yuki::perception::SensoryObservation& obs,
    const BeliefState& belief) const
{
    auto map_state = belief.getMAP();
    auto predicted = likelihood(map_state, obs.modality);
    std::vector<float> error;
    size_t n = std::min(obs.features.size(), predicted.size());
    for (size_t i = 0; i < n; ++i) {
        error.push_back(obs.features.values[i] - predicted.values[i]);
    }
    return error;
}

yuki::perception::PrecisionMatrix GenerativeModel::expectedPrecision(
    yuki::perception::Modality modality) const
{
    yuki::perception::PrecisionMatrix prec;
    switch (modality) {
        case yuki::perception::Modality::AUDIO:
            prec.setUniform(8, 1.5f); break;
        case yuki::perception::Modality::VISUAL_CAMERA:
            prec.setUniform(10, 1.0f); break;
        case yuki::perception::Modality::VISUAL_SCREEN:
            prec.setUniform(8, 0.8f); break;
        case yuki::perception::Modality::TEXT:
            prec.setUniform(12, 2.0f); break;
        default:
            prec.setUniform(1, 1.0f);
    }
    return prec;
}

void GenerativeModel::initializeMappings_() {
    intent_to_text_features_[static_cast<size_t>(yuki::IntentClass::QUERY)] = {0.3f, 0.2f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    intent_to_text_features_[static_cast<size_t>(yuki::IntentClass::COMMAND)] = {0.3f, 0.2f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f};
    intent_to_text_features_[static_cast<size_t>(yuki::IntentClass::TUTORIAL)] = {0.5f, 0.4f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f};
    intent_to_text_features_[static_cast<size_t>(yuki::IntentClass::EMOTIONAL_VENT)] = {0.4f, 0.3f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.5f, 0.8f};
    for (size_t i = 0; i < 8; ++i) {
        if (intent_to_text_features_[i].empty()) {
            intent_to_text_features_[i] = std::vector<float>(12, 0.5f);
        }
    }
    for (size_t i = 0; i < 8; ++i) {
        intent_to_audio_features_[i] = std::vector<float>(8, 0.3f);
    }
    for (size_t i = 0; i < 8; ++i) {
        intent_to_visual_features_[i] = std::vector<float>(10, 0.4f);
    }
}

void GenerativeModel::bootstrapStructuralPriors() {
    intent_to_text_features_[static_cast<size_t>(yuki::IntentClass::QUERY)][0] = 0.9f;  // (Question for QUERY)
    intent_to_text_features_[static_cast<size_t>(yuki::IntentClass::QUERY)][8] = 0.8f;  // (Phatic for QUERY)
    intent_to_text_features_[static_cast<size_t>(yuki::IntentClass::COMMAND)][1] = 0.9f; // (Command for COMMAND)
    std::cout << "[GenerativeModel] structural priors bootstrapped" << std::endl;
}
// ── Learning: Update generative model from observations ─────────────────────

void GenerativeModel::updateMapping(yuki::IntentClass intent,
                                     yuki::perception::Modality modality,
                                     const std::vector<float>& observed_features,
                                     float learning_rate)
{
    size_t intent_idx = static_cast<size_t>(intent);
    if (intent_idx >= 8) return;

    std::vector<float>* target = nullptr;
    size_t expected_dims = 0;
    switch (modality) {
        case yuki::perception::Modality::AUDIO:
            target = &intent_to_audio_features_[intent_idx];
            expected_dims = 8;
            break;
        case yuki::perception::Modality::VISUAL_CAMERA:
            target = &intent_to_visual_features_[intent_idx];
            expected_dims = 10;
            break;
        case yuki::perception::Modality::VISUAL_SCREEN:
            target = nullptr; // Screen features don't map to intent directly
            return;
        case yuki::perception::Modality::TEXT:
            target = &intent_to_text_features_[intent_idx];
            expected_dims = 12;
            break;
        default:
            return;
    }

    if (!target || target->empty()) {
        // Initialize if not already set
        if (target) target->assign(expected_dims, 0.5f);
        return;
    }

    // EMA update: mapping = (1 - lr) * mapping + lr * observed
    size_t n = std::min(target->size(), observed_features.size());
    for (size_t i = 0; i < n; ++i) {
        (*target)[i] = (1.0f - learning_rate) * (*target)[i] + learning_rate * observed_features[i];
    }

    // Clamp to [0, 1] to keep features in valid range
    for (auto& v : *target) {
        v = std::max(0.0f, std::min(1.0f, v));
    }
}

void GenerativeModel::decayMappings_(float decay_factor) {
    for (size_t i = 0; i < 8; ++i) {
        for (auto& v : intent_to_audio_features_[i]) {
            v = decay_factor * v + (1.0f - decay_factor) * 0.5f;
        }
        for (auto& v : intent_to_visual_features_[i]) {
            v = decay_factor * v + (1.0f - decay_factor) * 0.5f;
        }
        for (auto& v : intent_to_text_features_[i]) {
            v = decay_factor * v + (1.0f - decay_factor) * 0.5f;
        }
    }
}

std::vector<float> GenerativeModel::getMapping(yuki::IntentClass intent,
                                                yuki::perception::Modality modality) const
{
    size_t intent_idx = static_cast<size_t>(intent);
    if (intent_idx >= 8) return {};

    switch (modality) {
        case yuki::perception::Modality::AUDIO:
            return intent_to_audio_features_[intent_idx];
        case yuki::perception::Modality::VISUAL_CAMERA:
            return intent_to_visual_features_[intent_idx];
        case yuki::perception::Modality::TEXT:
            return intent_to_text_features_[intent_idx];
        default:
            return {};
    }
}

// ── Persistence: Save/load to SQLite ────────────────────────────────────────

bool GenerativeModel::saveMappings(const std::string& db_path) {
    // Simple CSV fallback (no new SQLite dependency)
    std::ofstream ofs(db_path + ".csv");
    if (!ofs.is_open()) return false;

    ofs << "intent,modality,dim0,dim1,dim2,dim3,dim4,dim5,dim6,dim7,dim8,dim9,dim10,dim11\n";
    for (size_t i = 0; i < 8; ++i) {
        auto intent = static_cast<yuki::IntentClass>(i);
        auto audio = getMapping(intent, yuki::perception::Modality::AUDIO);
        auto visual = getMapping(intent, yuki::perception::Modality::VISUAL_CAMERA);
        auto text = getMapping(intent, yuki::perception::Modality::TEXT);

        ofs << i << ",audio,";
        for (size_t j = 0; j < audio.size() && j < 12; ++j) ofs << audio[j] << ",";
        ofs << "\n";

        ofs << i << ",visual,";
        for (size_t j = 0; j < visual.size() && j < 12; ++j) ofs << visual[j] << ",";
        ofs << "\n";

        ofs << i << ",text,";
        for (size_t j = 0; j < text.size() && j < 12; ++j) ofs << text[j] << ",";
        ofs << "\n";
    }
    return true;
}

bool GenerativeModel::loadMappings(const std::string& db_path) {
    std::ifstream ifs(db_path + ".csv");
    if (!ifs.is_open()) return false;

    std::string line;
    std::getline(ifs, line); // skip header
    while (std::getline(ifs, line)) {
        std::istringstream iss(line);
        std::string intent_str, modality_str;
        std::getline(iss, intent_str, ',');
        std::getline(iss, modality_str, ',');

        int intent_idx = std::stoi(intent_str);
        if (intent_idx < 0 || intent_idx >= 8) continue;

        std::vector<float> vals;
        std::string val;
        while (std::getline(iss, val, ',')) {
            if (!val.empty()) vals.push_back(std::stof(val));
        }

        yuki::perception::Modality mod = yuki::perception::Modality::UNKNOWN;
        if (modality_str == "audio") mod = yuki::perception::Modality::AUDIO;
        else if (modality_str == "visual") mod = yuki::perception::Modality::VISUAL_CAMERA;
        else if (modality_str == "text") mod = yuki::perception::Modality::TEXT;

        if (mod != yuki::perception::Modality::UNKNOWN) {
            auto* target = const_cast<std::vector<float>*>(
                (mod == yuki::perception::Modality::AUDIO) ? &intent_to_audio_features_[intent_idx] :
                (mod == yuki::perception::Modality::VISUAL_CAMERA) ? &intent_to_visual_features_[intent_idx] :
                &intent_to_text_features_[intent_idx]
            );
            if (target && !vals.empty()) {
                target->assign(vals.begin(), vals.begin() + std::min(vals.size(), target->size()));
            }
        }
    }
    return true;
}

}
