#include "VariationalStateEstimator.h"
#include <cmath>
#include <chrono>

namespace yuki::inference {

VariationalStateEstimator::VariationalStateEstimator() {
    reset();
}

PolicyResult VariationalStateEstimator::update(
    const yuki::perception::SensoryObservation& observation,
    const PrecisionFactors& factors)
{
    auto start_time = std::chrono::steady_clock::now();
    auto precision = precision_engine_.computePrecision(observation, belief_state_, factors);
    // Invalidate policy cache since observation changed
    free_energy_calc_.invalidateCache();
    auto prediction_error = generative_model_.predictionError(observation, belief_state_);
    std::vector<float> prec_vec;
    for (size_t i = 0; i < precision.diagonal.size(); ++i) {
        prec_vec.push_back(precision.diagonal[i]);
    }
    belief_state_.update(prediction_error, prec_vec, 0.1f);
    float F = free_energy_calc_.computeF(belief_state_, prediction_error, prec_vec);
    (void)F; // Unused for now
    auto policy_result = policy_selector_.selectPolicy(belief_state_, generative_model_, free_energy_calc_);
    prior_belief_ = belief_state_;
    last_policy_result_ = policy_result;

    // Learning: update generative model from this observation
    // Uses the MAP intent as the label and the observed features as the target
    auto map_state = belief_state_.getMAP();
    generative_model_.updateMapping(map_state.intent, observation.modality, 
                                     observation.features.values, 0.05f);

    // Periodic decay to prevent overfitting (every 100 turns)
    static int turn_count = 0;
    if (++turn_count % 100 == 0) {
        generative_model_.decayMappings_(0.999f);
    }

    // Performance tracking
    auto end_time = std::chrono::steady_clock::now();
    last_update_time_ms_ = std::chrono::duration<float, std::milli>(end_time - start_time).count();
    last_eval_count_ = 0; // TODO: wire from FreeEnergyCalculator if needed

    return policy_result;
}

void VariationalStateEstimator::reset() {
    belief_state_.reset();
    prior_belief_.reset();
    precision_engine_ = PrecisionEngine();
    generative_model_ = GenerativeModel();
    free_energy_calc_ = FreeEnergyCalculator();
    policy_selector_ = PolicySelector();
    last_policy_result_ = PolicyResult{};
}

void VariationalStateEstimator::reportOutcome(const std::string& source_id, bool was_correct) {
    precision_engine_.updateHistoricalAccuracy(source_id, was_correct);
}

PrecisionFactors VariationalStateEstimator::extractFactors_(const yuki::perception::SensoryObservation& obs) const {
    (void)obs; // To avoid unused param warning
    PrecisionFactors f;
    f.signal_snr = 30.0f;
    return f;
}
}
